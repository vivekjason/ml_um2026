"""
validate_synthetic.py -- sanity-check that nhms_synthetic.csv has the teaching properties we want.
Run after simulate_nhms_synthetic.py. Uses scikit-learn only as a quick independent check;
the workshop itself is in R.
"""
import numpy as np, pandas as pd
from pathlib import Path
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import cross_val_score, StratifiedKFold

p = Path(__file__).resolve().parent.parent / "data" / "nhms_synthetic.csv"
df = pd.read_csv(p).replace(-9, np.nan)
print(df.shape)
print("prevalence:", {c: round(df[c].mean(), 3) for c in ["undx_dm", "undx_hpt", "undx_chol"]})
print("missing % (top):")
print((df.isna().mean() * 100).round(1).sort_values(ascending=False).head(12).to_string())

outcomes = ["undx_dm", "undx_hpt", "undx_chol", "dm", "hpt", "chol", "id"]
# one-hot the nominal codes so logistic regression gets the same chance it would in R
nominal = ["ethnic", "married", "education", "income", "occupation", "smoke", "age_cat", "bmi_cat", "pa_3cat"]
df = pd.get_dummies(df, columns=nominal, dummy_na=False, dtype=float)
leaky = {"undx_dm": ["rbs"], "undx_hpt": ["sys", "dys"], "undx_chol": ["rchol"]}
cv = StratifiedKFold(5, shuffle=True, random_state=1)

def models():
    return {
        "logistic": make_pipeline(SimpleImputer(), StandardScaler(), LogisticRegression(max_iter=2000)),
        "rf": make_pipeline(SimpleImputer(), RandomForestClassifier(500, min_samples_leaf=5, n_jobs=-1, random_state=1)),
        "gbm": HistGradientBoostingClassifier(max_iter=300, learning_rate=0.05, max_depth=4, random_state=1),
        "mlp": make_pipeline(SimpleImputer(), StandardScaler(), MLPClassifier((16,), alpha=3.0, max_iter=800, early_stopping=True, random_state=1)),
    }

for tgt in ["undx_dm", "undx_hpt"]:
    X_all = df.drop(columns=outcomes)
    for label, drop in [("WITH leaky biomarkers", []), ("honest predictors", leaky[tgt] + ["rbs", "sys", "dys", "rchol"])]:
        X = X_all.drop(columns=[c for c in drop if c in X_all])
        print(f"\n== {tgt}  ({label}; {X.shape[1]} predictors)")
        for name, m in models().items():
            s = cross_val_score(m, X, df[tgt], cv=cv, scoring="roc_auc")
            print(f"   {name:9s} CV AUC = {s.mean():.3f} +/- {s.std():.3f}")
