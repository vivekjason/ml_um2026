"""Generate the conceptual figures used in the slide decks (images/gen/*.png). Pure matplotlib, no data needed."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "images" / "gen"
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 13, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})
BLUE, ORANGE, GREY, GREEN, RED = "#0b4f6c", "#d97706", "#6b7280", "#15803d", "#b91c1c"
rng = np.random.default_rng(1)

def save(name):
    plt.tight_layout(); plt.savefig(OUT / name, bbox_inches="tight"); plt.close()

# 1. bias-variance U curve -------------------------------------------------------
x = np.linspace(0.5, 10, 200)
train = 1.6 * np.exp(-0.45 * x) + 0.05
test = train + 0.012 * (x - 1) ** 2 + 0.12
plt.figure(figsize=(7, 4))
plt.plot(x, train, color=BLUE, lw=2.5, label="training error")
plt.plot(x, test, color=ORANGE, lw=2.5, label="test error (what you care about)")
opt = x[np.argmin(test)]
plt.axvline(opt, color=GREY, ls="--"); plt.text(opt + 0.15, 1.25, "sweet spot", color=GREY)
plt.text(1, 1.5, "underfitting\n(high bias)", color=GREY); plt.text(7.3, 1.5, "overfitting\n(high variance)", color=GREY)
plt.xlabel("model complexity  (depth, units, 1/penalty ...)"); plt.ylabel("error"); plt.xticks([]); plt.yticks([])
plt.legend(frameon=False, loc="upper center"); save("bias_variance_curve.png")

# 2. activation functions --------------------------------------------------------
z = np.linspace(-5, 5, 400)
fig, ax = plt.subplots(1, 3, figsize=(11, 3.4))
for a, (name, f) in zip(ax, [("sigmoid  1/(1+e^-z)", 1 / (1 + np.exp(-z))), ("tanh", np.tanh(z)), ("ReLU  max(0, z)", np.maximum(0, z))]):
    a.plot(z, f, color=BLUE, lw=2.5); a.set_title(name); a.axhline(0, color=GREY, lw=.6); a.axvline(0, color=GREY, lw=.6); a.set_xlabel("z = weighted sum")
save("activations.png")

# 3. gradient descent & learning rate -------------------------------------------
w = np.linspace(-3, 3, 300); L = w ** 2
fig, ax = plt.subplots(1, 3, figsize=(11, 3.4))
for a, (lr, title) in zip(ax, [(0.05, "too small: slow"), (0.4, "about right"), (1.05, "too large: diverges")]):
    a.plot(w, L, color=GREY, lw=1.5); p = 2.6; pts = [p]
    for _ in range(12):
        p = p - lr * 2 * p; pts.append(p)
    pts = np.array(pts); pts = pts[np.abs(pts) < 3.2]
    a.plot(pts, pts ** 2, "o-", color=ORANGE, ms=5); a.set_title(f"learning rate {lr}: {title}"); a.set_xlabel("weight"); a.set_ylabel("loss"); a.set_ylim(-0.3, 10)
save("gradient_descent_lr.png")

# 4. network diagrams --------------------------------------------------------------
def draw_net(layers, labels, fname, title, show_bias=False):
    fig, ax = plt.subplots(figsize=(8, 4.2)); ax.axis("off"); ax.set_title(title)
    xs = np.linspace(0.1, 0.9, len(layers)); pos = {}
    for li, (n, x) in enumerate(zip(layers, xs)):
        ys = np.linspace(0.15, 0.85, n) if n > 1 else [0.5]
        for ni, y in enumerate(ys):
            pos[(li, ni)] = (x, y)
            col = BLUE if li == len(layers) - 1 else (ORANGE if li > 0 else GREY)
            ax.add_patch(Circle((x, y), 0.035, color=col, zorder=3))
        ax.text(x, 0.02, labels[li], ha="center", color=GREY)
    for li in range(len(layers) - 1):
        for a in range(layers[li]):
            for b in range(layers[li + 1]):
                (x1, y1), (x2, y2) = pos[(li, a)], pos[(li + 1, b)]
                ax.plot([x1, x2], [y1, y2], color="#cbd5e1", lw=0.8, zorder=1)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    plt.savefig(OUT / fname, bbox_inches="tight"); plt.close()
draw_net([4, 1], ["inputs x", "sigmoid(w·x + b)"], "logistic_neuron.png", "Logistic regression IS a neuron")
draw_net([2, 8, 1], ["2 inputs", "8 hidden (tanh)", "output (sigmoid)"], "mlp_2_8_1.png", "The 40-line network from Demo 6: 2 → 8 → 1")
draw_net([6, 16, 8, 1], ["inputs", "hidden 1 (ReLU)", "hidden 2 (ReLU)", "P(Yes)"], "mlp_deep.png", "A 'deep' multilayer perceptron (brulee: 32 → 16)")

# 5. ROC vs PR at low prevalence ----------------------------------------------------
from sklearn.metrics import roc_curve, precision_recall_curve, roc_auc_score, average_precision_score
n = 20000; prev = 0.116
y = rng.random(n) < prev
def scores(sep):  # latent normal with class separation
    return np.where(y, rng.normal(sep, 1, n), rng.normal(0, 1, n))
fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
for sep, col, lab in [(1.5, BLUE, "good model"), (0.6, ORANGE, "weak model")]:
    s = scores(sep); fpr, tpr, _ = roc_curve(y, s); pr, rc, _ = precision_recall_curve(y, s)
    ax[0].plot(fpr, tpr, color=col, lw=2.5, label=f"{lab}  AUC={roc_auc_score(y, s):.2f}")
    ax[1].plot(rc, pr, color=col, lw=2.5, label=f"{lab}  PR-AUC={average_precision_score(y, s):.2f}")
ax[0].plot([0, 1], [0, 1], ls="--", color=GREY); ax[0].set_xlabel("1 - specificity (false positive rate)"); ax[0].set_ylabel("sensitivity"); ax[0].set_title("ROC: prevalence-blind"); ax[0].legend(frameon=False)
ax[1].axhline(prev, ls="--", color=GREY); ax[1].text(0.02, prev + 0.02, "baseline = prevalence 0.116", color=GREY); ax[1].set_xlabel("recall (sensitivity)"); ax[1].set_ylabel("precision (PPV)"); ax[1].set_title("Precision-recall: what the positives are worth"); ax[1].legend(frameon=False); ax[1].set_ylim(0, 1)
save("roc_vs_pr.png")

# 6. calibration illustration ---------------------------------------------------------
p = np.linspace(0.01, 0.99, 50)
fig, ax = plt.subplots(figsize=(5.2, 5))
ax.plot([0, 1], [0, 1], ls="--", color=GREY, label="perfect")
ax.plot(p, p ** 1.8 / (p ** 1.8 + (1 - p) ** 1.8) * 0.75 + 0.03, color=ORANGE, lw=2.5, label="over-confident (S-shape)")
ax.plot(p, 0.6 * p + 0.2 * p ** 2 + 0.05, color=BLUE, lw=2.5, label="predicts too high")
ax.set_xlabel("predicted probability"); ax.set_ylabel("observed event rate"); ax.set_title("Reliability diagram"); ax.legend(frameon=False, loc="upper left")
save("calibration_illustration.png")

# 7. PPV vs prevalence ----------------------------------------------------------------
prev = np.linspace(0.005, 0.5, 200)
fig, ax = plt.subplots(figsize=(7, 4))
for sens, spec, col in [(0.80, 0.75, ORANGE), (0.80, 0.90, BLUE), (0.95, 0.95, GREEN)]:
    ppv = sens * prev / (sens * prev + (1 - spec) * (1 - prev))
    ax.plot(prev, ppv, lw=2.5, color=col, label=f"sens {sens:.2f}, spec {spec:.2f}")
for pv, lab in [(0.116, "NHMS undx DM"), (0.03, "community screen"), (0.3, "clinic")]:
    ax.axvline(pv, color=GREY, lw=0.8, ls=":"); ax.text(pv + 0.005, 0.97, lab, rotation=90, va="top", color=GREY, fontsize=10)
ax.set_xlabel("prevalence in the population you deploy in"); ax.set_ylabel("PPV"); ax.set_title("Same model, same sens/spec - PPV depends on prevalence"); ax.legend(frameon=False, loc="lower right")
save("ppv_vs_prevalence.png")

# 8. threshold trade-off ------------------------------------------------------------
y = rng.random(5000) < 0.116; s = np.where(y, rng.normal(1.5, 1, 5000), rng.normal(0, 1, 5000)); pr_ = 1 / (1 + np.exp(-(s - 2.2)))
ths = np.linspace(0.02, 0.8, 100)
sens = [np.mean(pr_[y] >= t) for t in ths]; spec = [np.mean(pr_[~y] < t) for t in ths]; flagged = [np.mean(pr_ >= t) for t in ths]
fig, ax = plt.subplots(figsize=(7, 4))
ax.plot(ths, sens, color=BLUE, lw=2.5, label="sensitivity"); ax.plot(ths, spec, color=ORANGE, lw=2.5, label="specificity"); ax.plot(ths, flagged, color=GREY, lw=2, ls="--", label="% flagged")
ax.axvline(0.5, color=RED, lw=1); ax.text(0.51, 0.5, "software default", color=RED, fontsize=10)
ax.set_xlabel("threshold on P(Yes)"); ax.set_ylabel(""); ax.set_title("0.5 is not a clinical decision"); ax.legend(frameon=False)
save("threshold_tradeoff.png")

# 9. regular vs space-filling grid ------------------------------------------------------
fig, ax = plt.subplots(1, 2, figsize=(9, 4))
g = np.array([(a, b) for a in np.linspace(0, 1, 4) for b in np.linspace(0, 1, 4)])
ax[0].scatter(g[:, 0], g[:, 1], s=60, color=BLUE); ax[0].set_title("regular grid: 4 x 4 = 16\n(only 4 distinct values per parameter)")
from scipy.stats import qmc
lh = qmc.LatinHypercube(d=2, seed=3).random(16)
ax[1].scatter(lh[:, 0], lh[:, 1], s=60, color=ORANGE); ax[1].set_title("space-filling: 16\n(16 distinct values per parameter)")
for a in ax: a.set_xlabel("learn_rate (log)"); a.set_ylabel("tree_depth"); a.set_xticks([]); a.set_yticks([])
save("grids.png")

# 10. boosting: learning rate vs iterations --------------------------------------------------
it = np.arange(1, 501)
fig, ax = plt.subplots(figsize=(7, 4))
for lr, col, lab in [(0.3, RED, "learn_rate 0.3: fast, then overfits"), (0.05, BLUE, "learn_rate 0.05: slower, lower minimum"), (0.005, GREY, "learn_rate 0.005: too slow for 500 trees")]:
    k = lr * 20; curve = 0.42 * np.exp(-k * it / 50) + 0.30 + (0.00022 * it if lr == 0.3 else 0.00004 * it if lr == 0.05 else 0)
    ax.plot(it, curve, color=col, lw=2.5, label=lab)
ax.set_xlabel("number of trees"); ax.set_ylabel("validation loss"); ax.set_title("Boosting: learning rate and number of trees trade off"); ax.legend(frameon=False)
save("boosting_learning_rate.png")

# 11. NN boundary evolution on the ring toy (numpy replica of the R demo) -----------------
n = 300; r = np.r_[rng.uniform(0, 1.0, n // 2), rng.uniform(1.6, 2.6, n // 2)]; th = rng.uniform(0, 2 * np.pi, n)
X = np.c_[r * np.cos(th), r * np.sin(th)] + rng.normal(0, 0.15, (n, 2)); yv = np.r_[np.ones(n // 2), np.zeros(n // 2)].reshape(-1, 1)
sig = lambda z: 1 / (1 + np.exp(-z)); H = 8; lr = 0.5
W1 = rng.normal(0, 0.5, (2, H)); b1 = np.zeros((1, H)); W2 = rng.normal(0, 0.5, (H, 1)); b2 = np.zeros((1, 1)); snaps = {}
gx, gy = np.meshgrid(np.linspace(-3, 3, 150), np.linspace(-3, 3, 150)); G = np.c_[gx.ravel(), gy.ravel()]
for ep in range(1, 501):
    A1 = np.tanh(X @ W1 + b1); P = sig(A1 @ W2 + b2)
    dZ2 = (P - yv) / n; dW2 = A1.T @ dZ2; db2 = dZ2.sum(0, keepdims=True); dZ1 = (dZ2 @ W2.T) * (1 - A1 ** 2); dW1 = X.T @ dZ1; db1 = dZ1.sum(0, keepdims=True)
    W1 -= lr * dW1; b1 -= lr * db1; W2 -= lr * dW2; b2 -= lr * db2
    if ep in (1, 10, 50, 500): snaps[ep] = sig(np.tanh(G @ W1 + b1) @ W2 + b2).reshape(gx.shape)
fig, ax = plt.subplots(1, 4, figsize=(13, 3.4))
for a, (ep, Pg) in zip(ax, snaps.items()):
    a.contourf(gx, gy, Pg, levels=20, cmap="viridis", vmin=0, vmax=1); a.scatter(X[:, 0], X[:, 1], c=np.where(yv.ravel() == 1, "white", "black"), s=6); a.set_title(f"epoch {ep}"); a.set_aspect("equal"); a.set_xticks([]); a.set_yticks([])
save("nn_boundary_evolution.png")

# 12. imbalance: what SMOTE does to probabilities -------------------------------------------
fig, ax = plt.subplots(figsize=(7, 4))
p_true = np.linspace(0.01, 0.6, 100)
odds = p_true / (1 - p_true); p_smote = (odds * (0.884 / 0.116)) / (1 + odds * (0.884 / 0.116))
ax.plot(p_true, p_true, ls="--", color=GREY, label="honest model"); ax.plot(p_true, p_smote, color=ORANGE, lw=2.5, label="same model trained on 50/50 SMOTE data")
ax.axhline(0.5, color=RED, lw=0.8); ax.text(0.42, 0.52, "0.5 threshold", color=RED, fontsize=10)
ax.set_xlabel("true probability"); ax.set_ylabel("predicted probability"); ax.set_title("Balancing the training set = moving the threshold in disguise"); ax.legend(frameon=False)
save("smote_shifts_probabilities.png")

# 13. two-day map ---------------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(11, 2.6)); ax.axis("off")
steps = ["Question", "Data +\nleakage audit", "Split", "Recipe", "Model(s)", "Resample\n& tune", "Evaluate\n& calibrate", "Explain", "Decide\n& report"]
days = [BLUE] * 5 + [ORANGE] * 4
for i, (s, c) in enumerate(zip(steps, days)):
    ax.add_patch(plt.Rectangle((i * 1.2, 0), 1.05, 1, color=c, alpha=0.9)); ax.text(i * 1.2 + 0.52, 0.5, s, ha="center", va="center", color="white", fontsize=11, weight="bold")
    if i < len(steps) - 1: ax.annotate("", xy=(i * 1.2 + 1.2, 0.5), xytext=(i * 1.2 + 1.05, 0.5), arrowprops=dict(arrowstyle="->", color=GREY))
ax.text(2.9, -0.35, "Day 1 · build", color=BLUE, ha="center", fontsize=12, weight="bold"); ax.text(8.3, -0.35, "Day 2 · trust, explain, go deeper, capstone", color=ORANGE, ha="center", fontsize=12, weight="bold")
ax.set_xlim(-0.1, 10.9); ax.set_ylim(-0.6, 1.1); save("two_day_map.png")

# 14. sigmoid of a linear score (logistic) vs a bent score ----------------------------------------
print("figures written to", OUT); print(sorted(p.name for p in OUT.iterdir()))

# 15. four decision boundaries on a toy problem (two moons) ----------------------------------------
from sklearn.datasets import make_moons
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
Xm, ym = make_moons(n_samples=400, noise=0.3, random_state=7)
ga, gb = np.meshgrid(np.linspace(-2, 3, 200), np.linspace(-1.5, 2, 200)); Gab = np.c_[ga.ravel(), gb.ravel()]
models = [("Logistic regression: one straight line", LogisticRegression()),
          ("SVM, RBF kernel: smooth curves", SVC(C=1, gamma=1, probability=True, random_state=1)),
          ("kNN (k = 15): local, patchy", KNeighborsClassifier(15)),
          ("Random forest: axis-aligned steps", RandomForestClassifier(300, min_samples_leaf=5, random_state=1))]
fig, ax = plt.subplots(2, 2, figsize=(11, 8.5)); fig.subplots_adjust(hspace=0.35, wspace=0.25)
for a, (title, m) in zip(ax.ravel(), models):
    m.fit(Xm, ym); P = m.predict_proba(Gab)[:, 1].reshape(ga.shape)
    cs = a.contourf(ga, gb, P, levels=np.linspace(0, 1, 11), cmap="viridis"); a.contour(ga, gb, P, levels=[0.5], colors="white", linewidths=1.5)
    a.scatter(Xm[:, 0], Xm[:, 1], c=np.where(ym == 1, "white", "black"), s=8, alpha=0.8)
    a.set_title(title, fontsize=12); a.set_xticks([]); a.set_yticks([])
fig.colorbar(cs, ax=ax.ravel().tolist(), label="P(class = 1)   white line: P = 0.5", shrink=0.8)
plt.savefig(OUT / "boundaries_toy.png", bbox_inches="tight"); plt.close()
print("boundaries written")
