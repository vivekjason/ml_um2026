"""Extract plain R scripts (demos/*.R) from tutorials/*.qmd. Mirror of instructor/purl_demos.R for environments without R."""
import re, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
(root / "demos").mkdir(exist_ok=True)
for q in sorted((root / "tutorials").glob("*.qmd")):
    s = q.read_text()
    title = re.search(r'^title:\s*"(.*)"', s, re.M).group(1)
    out = [f"# {'='*77}", f"# {title}",
           f"# Extracted from tutorials/{q.name} - the tutorial is the source of truth (instructor/purl_demos.R regenerates this).",
           "# Run chunk by chunk with Ctrl+Enter. '## ----' lines are the tutorial's chunk labels.", f"# {'='*77}", ""]
    for m in re.finditer(r'(^#{1,3} [^\n]*$)|(```\{r\}\n(.*?)```)', s, re.M | re.S):
        if m.group(1):
            h = m.group(1).strip("# ").strip()
            out += ["", f"# ---- {h} " + "-" * max(0, 70 - len(h)), ""]
        else:
            body = m.group(3)
            opts = dict(re.findall(r'^#\|\s*([\w-]+):\s*(.*)$', body, re.M))
            code = re.sub(r'^#\|.*\n', '', body, flags=re.M).rstrip("\n")
            label = opts.get("label", "chunk")
            if opts.get("eval", "true").strip().lower() == "false":
                out += [f"## ---- {label} (YOUR TURN: fill the blanks; not run as-is) ----"] + ["# " + l for l in code.split("\n")] + [""]
            else:
                out += [f"## ---- {label} ----", code, ""]
    dest = root / "demos" / (q.stem + ".R")
    dest.write_text("\n".join(out) + "\n")
    print(dest.name, "written")
