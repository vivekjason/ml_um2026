"""
simulate_nhms_synthetic.py
--------------------------
Generates `data/nhms_synthetic.csv` for the UM CePH "Predictive Intelligence" workshop.

WHY THIS EXISTS
The 2023 workshop used `nhms_dummy.csv`, built by scrambling each column of a confidential
NHMS 2015 extract independently. That protects privacy perfectly but also destroys every
relationship between variables: cross-validated AUC for all three outcomes is ~0.50.
For teaching we need data with *known, controllable* structure, so this script simulates a
population from scratch. Nothing here is derived from real NHMS records.

DESIGN GOALS (checked by validate_synthetic.py)
  * Same column names and codings as nhms_dummy.csv so the 2023 narrative carries over.
  * Realistic Malaysian NCD risk gradients (age, BMI, waist, ethnicity, family history,
    activity, income, education) -> logistic regression AUC ~0.75-0.80 for undx_dm.
  * Some non-linearity and interactions so tree ensembles / neural nets beat logistic
    regression by a visible but not absurd margin (~+0.03-0.05 AUC).
  * Deliberate TARGET LEAKAGE: `rbs` (random blood sugar) is generated FROM undx_dm,
    `sys`/`dys` FROM undx_hpt, `rchol` FROM undx_chol -- exactly as in NHMS, where the
    undiagnosed outcome is *defined* by that measurement. Including them gives AUC ~0.97.
  * Realistic missingness (MAR), plus `-9` sentinel codes in biomarker columns that must be
    recoded to NA (the 2023 code never did this).
  * `dm`, `hpt`, `chol` are all 0 (sample is "no known diagnosis" by construction) -> teaches
    step_zv().

Run:  python simulate_nhms_synthetic.py   (writes ../data/nhms_synthetic.csv)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path

SEED = 20261111          # 11 Nov 2026, day 1 of the workshop
N = 5000
NONLIN_SCALE = 1.5       # dial: how much thresholds/interactions matter (trees & NNs vs GLM)
rng = np.random.default_rng(SEED)

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def bern(p):
    return (rng.random(len(p)) < p).astype(int)

# ----------------------------------------------------------------------------- demographics
sex = rng.choice([1, 2], size=N, p=[0.53, 0.47])                      # 1 Female, 2 Male
age = np.clip(rng.gamma(shape=6.0, scale=6.8, size=N) + 18, 18, 92).round()
age_cat = pd.cut(age, [0, 29, 39, 49, 59, 200], labels=[1, 2, 3, 4, 5]).astype(int)
ethnic = rng.choice([1, 2, 3, 4, 5], size=N, p=[0.55, 0.22, 0.08, 0.12, 0.03])
# 1 Malay, 2 Chinese, 3 Indian, 4 Other Bumiputera, 5 Others
residential = rng.choice([1, 2], size=N, p=[0.30, 0.70])            # 1 Rural, 2 Urban
urban = (residential == 2).astype(int)

# marital status depends on age
p_married = sigmoid(-4 + 0.17 * age) * 0.85
p_wid = sigmoid(-9 + 0.12 * age) * 0.9
u = rng.random(N)
married = np.where(u < p_wid, 3, np.where(u < p_wid + p_married, 2, 1))  # 1 single 2 married 3 wid/div

# education: younger + urban -> higher
edu_lin = 1.2 - 0.03 * (age - 40) + 0.5 * urban + rng.normal(0, 1, N)
education = pd.cut(edu_lin, [-99, -0.6, 0.3, 1.6, 99], labels=[1, 2, 3, 4]).astype(int)
# 1 none, 2 primary, 3 secondary, 4 tertiary

# income group coded as in nhms_dummy: 1 M40, 2 T20, 3 B40
inc_lin = 0.35 * (education - 2.5) + 0.4 * urban + rng.normal(0, 1, N)
income = np.where(inc_lin > 1.1, 2, np.where(inc_lin > -0.1, 1, 3))
hh_income = np.where(income == 3, rng.lognormal(7.3, 0.35, N),
             np.where(income == 1, rng.lognormal(8.3, 0.30, N), rng.lognormal(9.2, 0.35, N))).round(0)

# occupation: 1 govt, 2 private, 3 self-employed, 4 homemaker/unpaid, 5 retired/student/unemployed
occ = np.empty(N, dtype=float)
for i in range(N):
    if age[i] >= 60:
        occ[i] = rng.choice([1, 2, 3, 4, 5], p=[0.03, 0.07, 0.25, 0.25, 0.40])
    elif age[i] <= 22:
        occ[i] = rng.choice([1, 2, 3, 4, 5], p=[0.03, 0.27, 0.10, 0.05, 0.55])
    elif sex[i] == 1:
        occ[i] = rng.choice([1, 2, 3, 4, 5], p=[0.15, 0.33, 0.14, 0.33, 0.05])
    else:
        occ[i] = rng.choice([1, 2, 3, 4, 5], p=[0.17, 0.45, 0.30, 0.02, 0.06])
occupation = occ

# ----------------------------------------------------------------------------- lifestyle
male = (sex == 2).astype(int)
p_smoke_cur = np.where(male == 1, 0.43, 0.012) * np.where(education == 4, 0.7, 1.0)
p_smoke_for = np.where(male == 1, 0.12, 0.01) + 0.002 * np.clip(age - 40, 0, None)
u = rng.random(N)
smoke = np.where(u < p_smoke_cur, 1, np.where(u < p_smoke_cur + p_smoke_for, 2, 3))  # 1 cur 2 former 3 never

p_alc = sigmoid(-3.2 + 1.6 * np.isin(ethnic, [2, 5]) + 1.0 * (ethnic == 3) + 0.9 * male
                + 0.6 * (ethnic == 4) - 0.02 * np.clip(age - 50, 0, None))
alcohol = np.where(bern(p_alc) == 1, 1, 2)                               # 1 yes 2 no

# physical activity (IPAQ-like): minutes per week drive pa_3cat; pa = 1 active / 2 inactive
act_lat = rng.normal(0, 1, N) - 0.015 * (age - 40) + 0.25 * male - 0.2 * urban
vig_day = np.clip(np.round(np.where(act_lat > 0.6, rng.poisson(2.5, N), rng.poisson(0.4, N))), 0, 7)
vig_min = np.where(vig_day > 0, np.clip(rng.normal(40, 15, N), 10, 180).round(), 0)
mod_day = np.clip(np.round(np.where(act_lat > -0.3, rng.poisson(2.5, N), rng.poisson(0.7, N))), 0, 7)
mod_min = np.where(mod_day > 0, np.clip(rng.normal(35, 15, N), 10, 180).round(), 0)
walk_day = np.clip(np.round(rng.poisson(np.clip(3.5 + act_lat, 0.2, None), N)), 0, 7)
walk_min = np.where(walk_day > 0, np.clip(rng.normal(30, 15, N), 10, 180).round(), 0)
met = 8 * vig_day * vig_min + 4 * mod_day * mod_min + 3.3 * walk_day * walk_min
pa_3cat = np.where(met >= 3000, 3, np.where(met >= 600, 2, 1))        # 1 low 2 mod 3 high
pa = np.where(pa_3cat >= 2, 1, 2)                                      # 1 active 2 inactive
inactive = (pa == 2).astype(int)

# fruit & veg servings/day; cons_fv 1 = adequate (>=5 servings), 2 = inadequate
mean_f = np.clip(rng.gamma(1.8, 0.45, N), 0, 8).round(2)
mean_v = np.clip(rng.gamma(2.5, 0.55, N), 0, 8).round(2)
cons_fv = np.where(mean_f + mean_v >= 5, 1, 2)

# ----------------------------------------------------------------------------- anthropometry
height = np.where(male == 1, rng.normal(166, 6.5, N), rng.normal(154, 6.0, N)).round(1)
bmi_lat = (24.5 + 0.045 * np.clip(age - 25, 0, 35) - 0.06 * np.clip(age - 60, 0, None)
           + 0.6 * (ethnic == 1) + 0.9 * (ethnic == 3) - 0.9 * (ethnic == 2) + 0.4 * (ethnic == 4)
           + 0.8 * inactive + 0.3 * urban - 0.3 * male + rng.normal(0, 4.3, N))
bmi = np.clip(bmi_lat, 14, 55).round(2)
weight = (bmi * (height / 100) ** 2).round(1)
waist = np.clip(bmi * 2.55 + np.where(male == 1, 22, 17) + rng.normal(0, 5, N), 55, 150).round(1)
bmi_cat = np.where(bmi < 25, 1, np.where(bmi < 30, 2, 3))              # 1 <25, 2 25-29.9, 3 >=30

# family history (NEW vs 2023 file) 1 yes 2 no
fam_hx_dm = np.where(bern(sigmoid(-1.3 + 0.5 * (ethnic == 3) + 0.2 * (ethnic == 1))) == 1, 1, 2)
fam_hx_hpt = np.where(bern(sigmoid(-1.0 + 0.3 * (ethnic == 1))) == 1, 1, 2)

# ----------------------------------------------------------------------------- outcomes
obese_asian = (bmi >= 27.5).astype(int)
fhx_dm = (fam_hx_dm == 1).astype(int)
fhx_hpt = (fam_hx_hpt == 1).astype(int)

# central obesity, Asian sex-specific cut-offs (M >= 90 cm, F >= 80 cm) -- an interaction that
# logistic regression only sees if someone engineers the feature; trees find it on their own
central_obese = ((male == 1) & (waist >= 90)) | ((male == 0) & (waist >= 80))
central_obese = central_obese.astype(int)

def calibrate_intercept(logit_no_b0, target):
    """bisection for the intercept that gives the target population prevalence"""
    lo, hi = -15.0, 15.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if sigmoid(mid + logit_no_b0).mean() > target:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2

# ---- undiagnosed diabetes (target prevalence ~11.5%)
# additive part (what logistic regression can learn directly)
age_eff_dm = np.where(age < 35, 0.0,
             np.where(age < 62, 0.065 * (age - 35),            # steep rise 35-62
                      0.065 * 27 - 0.035 * (age - 62)))         # plateau then decline (survivorship)
lin_dm = (age_eff_dm
          + 0.04 * (bmi - 25)
          + 0.25 * (ethnic == 3) + 0.30 * (ethnic == 1) + 0.20 * (ethnic == 4) + 0.10 * (ethnic == 5)
          + 0.45 * fhx_dm + 0.30 * obese_asian + 0.25 * central_obese
          + 0.20 * inactive + 0.25 * (income == 3) - 0.15 * (income == 2)
          + 0.20 * (education <= 2) + 0.10 * male + 0.12 * (residential == 1))
# non-additive part (thresholds + interactions: trees / neural nets find these, GLMs do not)
nonlin_dm = (1.50 * fhx_dm * obese_asian                       # family history x obesity
             + 0.90 * ((ethnic == 3) & (bmi >= 25))             # Indian x overweight
             + 0.80 * central_obese * inactive                  # central obesity x inactivity
             + 0.90 * ((age < 35) & (bmi >= 30))                # young-obese bump
             + 0.60 * ((male == 1) & (smoke == 1))              # male smokers only
             + 0.60 * ((income == 3) & (residential == 1) & (age >= 50)))  # rural poor elderly
logit_dm0 = lin_dm + NONLIN_SCALE * nonlin_dm
b0_dm = calibrate_intercept(logit_dm0, 0.115)
undx_dm = bern(sigmoid(b0_dm + logit_dm0))

# ---- undiagnosed hypertension (target prevalence ~23%)
age_eff_hpt = np.where(age < 30, 0.0, np.where(age < 65, 0.06 * (age - 30), 0.06 * 35 + 0.01 * (age - 65)))
lin_hpt = (age_eff_hpt
           + 0.35 * male + 0.04 * (bmi - 25) + 0.30 * central_obese + 0.20 * (bmi >= 30)
           + 0.25 * (ethnic == 1) + 0.20 * (ethnic == 3) + 0.30 * (ethnic == 4)
           + 0.40 * fhx_hpt + 0.25 * (alcohol == 1) + 0.15 * (smoke == 1)
           + 0.20 * inactive + 0.15 * (residential == 1) + 0.15 * (education <= 2))
nonlin_hpt = (1.10 * ((male == 0) & (age >= 55))               # women catch up after menopause
              + 1.20 * fhx_hpt * (bmi >= 30)                    # family history x obesity
              + 0.90 * ((alcohol == 1) & (smoke == 1))          # drinkers who smoke
              + 0.80 * central_obese * inactive
              + 0.70 * ((ethnic == 3) & (age >= 45)))
logit_hpt0 = lin_hpt + NONLIN_SCALE * nonlin_hpt
b0_hpt = calibrate_intercept(logit_hpt0, 0.23)
undx_hpt = bern(sigmoid(b0_hpt + logit_hpt0))

for nm, lin, nl in [("dm", lin_dm, NONLIN_SCALE * nonlin_dm), ("hpt", lin_hpt, NONLIN_SCALE * nonlin_hpt)]:
    print(f"{nm}: var(additive)={lin.var():.2f} var(non-additive)={nl.var():.2f} "
          f"share non-additive={nl.var()/(lin+nl).var():.2f}")

# ---- undiagnosed hypercholesterolaemia (target prevalence ~45%)
logit_chol0 = (0.03 * (age - 40) + 0.08 * (bmi - 25) + 0.20 * male
              + 0.30 * (ethnic == 3) + 0.10 * (ethnic == 2) + 0.20 * (cons_fv == 2)
              + 0.20 * inactive + 0.15 * (smoke == 1))
undx_chol = bern(sigmoid(calibrate_intercept(logit_chol0, 0.45) + logit_chol0))

# ----------------------------------------------------------------------------- LEAKY biomarkers
# In NHMS the undiagnosed outcome is DEFINED by these measurements. We reproduce that.
rbs = np.where(undx_dm == 1,
               np.clip(rng.lognormal(np.log(12.8), 0.22, N), 6.5, 33),
               np.clip(rng.normal(5.3, 1.05, N) + rng.exponential(0.5, N), 2.5, 13.5))
# a little realistic overlap: 8% of cases got a "borderline" reading, 2% of non-cases a high one
flip = rng.random(N)
rbs = np.where((undx_dm == 1) & (flip < 0.08), rng.uniform(7.5, 11.0, N), rbs)
rbs = np.where((undx_dm == 0) & (flip < 0.02), rng.uniform(11.1, 14.0, N), rbs)
rbs = rbs.round(1)

sys = np.where(undx_hpt == 1, rng.normal(149, 10, N), rng.normal(119, 10.5, N))
dys = np.where(undx_hpt == 1, rng.normal(92, 7.5, N), rng.normal(75.5, 7.5, N))
sys = np.where((undx_hpt == 1) & (flip < 0.10), rng.normal(134, 5, N), sys)
sys = np.where((undx_hpt == 0) & (flip < 0.03), rng.normal(141, 4, N), sys)
sys = np.clip(sys + 0.15 * (age - 40), 80, 250).round(1)
dys = np.clip(dys, 40, 170).round(1)

rchol = np.where(undx_chol == 1, rng.normal(6.2, 0.6, N), rng.normal(4.4, 0.55, N))
rchol = np.clip(rchol, 2.0, 10.5).round(2)

# ----------------------------------------------------------------------------- assemble
df = pd.DataFrame({
    "id": np.arange(1, N + 1),
    "sex": sex, "age": age.astype(int), "age_cat": age_cat, "ethnic": ethnic,
    "residential": residential, "married": married, "education": education,
    "income": income, "hh_income": hh_income, "occupation": occupation,
    "cons_fv": cons_fv, "alcohol": alcohol, "smoke": smoke, "pa": pa,
    "fam_hx_dm": fam_hx_dm, "fam_hx_hpt": fam_hx_hpt,
    "undx_dm": undx_dm, "undx_hpt": undx_hpt, "undx_chol": undx_chol,
    "hpt": 0, "dm": 0, "chol": 0,
    "bmi_cat": bmi_cat, "bmi": bmi, "waist": waist, "weight": weight, "height": height,
    "sys": sys, "dys": dys, "rbs": rbs, "rchol": rchol,
    "mean_f": mean_f, "mean_v": mean_v, "pa_3cat": pa_3cat,
    "vig_day": vig_day, "vig_min": vig_min, "mod_day": mod_day, "mod_min": mod_min,
    "walk_day": walk_day, "walk_min": walk_min,
})
df = df.astype({c: float for c in ["occupation", "education"]})

# ----------------------------------------------------------------------------- missingness
# anthropometry missing jointly, MAR (older + rural more likely)  ~7.5%
p_miss_anthro = sigmoid(-3.2 + 0.03 * np.clip(age - 50, 0, None) + 0.5 * (residential == 1))
m = bern(p_miss_anthro) == 1
df.loc[m, ["bmi", "bmi_cat", "weight", "height"]] = np.nan
m2 = m | (rng.random(N) < 0.004)
df.loc[m2, "waist"] = np.nan
# occupation ~17% missing (students, homemakers, elderly less likely to answer)
p_miss_occ = sigmoid(-2.2 + 0.9 * (age <= 22) + 0.8 * (age >= 60) + 0.6 * (occupation == 4))
df.loc[bern(p_miss_occ) == 1, "occupation"] = np.nan
# activity block ~0.9% jointly, education 0.8%, diet 0.4%
m = rng.random(N) < 0.009
df.loc[m, ["pa", "pa_3cat", "vig_day", "vig_min", "mod_day", "mod_min", "walk_day", "walk_min"]] = np.nan
df.loc[rng.random(N) < 0.008, "education"] = np.nan
m = rng.random(N) < 0.004
df.loc[m, ["cons_fv", "mean_f", "mean_v"]] = np.nan
df.loc[rng.random(N) < 0.003, "fam_hx_dm"] = np.nan
df.loc[rng.random(N) < 0.003, "fam_hx_hpt"] = np.nan

# -9 sentinel codes (as in the original export): BP ~4.6%, bloods ~6.9%, MCAR
m = rng.random(N) < 0.046
df.loc[m, ["sys", "dys"]] = -9
m = rng.random(N) < 0.069
df.loc[m, ["rbs", "rchol"]] = -9

# ----------------------------------------------------------------------------- write
out = Path(__file__).resolve().parent.parent / "data" / "nhms_synthetic.csv"
out.parent.mkdir(parents=True, exist_ok=True)
df.to_csv(out, index=False)
# true probabilities, for validation only (never shipped to participants)
pd.DataFrame({"id": df["id"], "p_dm": sigmoid(b0_dm + logit_dm0), "p_hpt": sigmoid(b0_hpt + logit_hpt0)}).to_csv(
    Path(__file__).resolve().parent / "_truth_for_validation.csv", index=False)
print(f"wrote {out}  shape={df.shape}")
print("prevalence:", {c: round(df[c].mean(), 3) for c in ["undx_dm", "undx_hpt", "undx_chol"]})
