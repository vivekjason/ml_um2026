# StatQuest watch-list — preparation for 11–12 November

All links were verified against the official StatQuest video index (statquest.org/video_index.html) and the
YouTube pages on 3 Nov 2026. Channel: https://www.youtube.com/@statquest ·
Machine Learning playlist (106 videos): https://www.youtube.com/playlist?list=PLblh5JKOoLUICTaGLRoHQDuF_7q2GfuJF ·
Neural Networks / Deep Learning playlist (33 videos): https://www.youtube.com/playlist?list=PLblh5JKOoLUIxGDQs4LFFD--41Vzf-ME1

**Priority:** ★★★ watch before you teach that session (the slides' pictures and worked examples come from these) ·
★★ watch if you have time (depth you will be asked about) · ★ optional.
Durations are given only where YouTube's page metadata exposed them (— = not shown; StatQuest videos are mostly 7–25 min). The 23 core (★★★) videos come to roughly 5–6 hours.

## Foundations — Sessions 1–2 and 6–7

| ★ | Video | Link | Length |
|---|---|---|---|
| ★★★ | Machine Learning Fundamentals: Bias and Variance | https://www.youtube.com/watch?v=EuBBz3bI-aA | — |
| ★★★ | Machine Learning Fundamentals: Cross Validation | https://www.youtube.com/watch?v=fSytzGwwBVw | — |
| ★★★ | Machine Learning Fundamentals: The Confusion Matrix | https://www.youtube.com/watch?v=Kdsp6soqA7o | — |
| ★★★ | Machine Learning Fundamentals: Sensitivity and Specificity | https://www.youtube.com/watch?v=vP06aMoz4v8 | — |
| ★★★ | ROC and AUC, Clearly Explained! | https://www.youtube.com/watch?v=4jRBRDbJemM | 16:17 |
| ★★★ | Gradient Descent, Step-by-Step | https://www.youtube.com/watch?v=sDv4f4s2SB8 | ≥ 23:06 |
| ★★ | Stochastic Gradient Descent, Clearly Explained!!! | https://www.youtube.com/watch?v=vMh0zPT0tLI | — |
| ★★ | Regularization Part 1: Ridge (L2) Regression | https://www.youtube.com/watch?v=Q81RR3yKn30 | — |
| ★★ | Regularization Part 2: Lasso (L1) Regression | https://www.youtube.com/watch?v=NGf0voTMlcs | — |
| ★ | StatQuest: Logistic Regression | https://www.youtube.com/watch?v=yIYKR4sgzI8 | — |
| ★ | Odds and Log(Odds), Clearly Explained!!! | https://www.youtube.com/watch?v=ARfXDSkQf1Y | — |
| ★ | Entropy (for data science) Clearly Explained!!! | https://www.youtube.com/watch?v=YtebGVx-Fxw | 16:34 |

## Session 3 — Decision trees and random forests

| ★ | Video | Link | Length |
|---|---|---|---|
| ★★★ | Decision and Classification Trees, Clearly Explained!!! | https://www.youtube.com/watch?v=_L39rN6gz7Y | — |
| ★★★ | StatQuest: Random Forests Part 1 — Building, Using and Evaluating | https://www.youtube.com/watch?v=J4Wdy0Wc_xQ | 9:54 |
| ★★ | StatQuest: Random Forests Part 2: Missing data and clustering | https://www.youtube.com/watch?v=mIlw5j3WyVk | — |
| ★★ | Regression Trees, Clearly Explained!!! | https://www.youtube.com/watch?v=g9c66TUylZ4 | 22:33 |
| ★ | How to Prune Regression Trees, Clearly Explained!!! | https://www.youtube.com/watch?v=D0efHEJsfHo | — |

## Session 4 — Support vector machines

| ★ | Video | Link | Length |
|---|---|---|---|
| ★★★ | Support Vector Machines Part 1 (of 3): Main Ideas!!! | https://www.youtube.com/watch?v=efR1C6CvhmE | 20:32 |
| ★★★ | Support Vector Machines Part 2: The Polynomial Kernel | https://www.youtube.com/watch?v=Toet3EiSFcM | — |
| ★★★ | Support Vector Machines Part 3: The Radial (RBF) Kernel | https://www.youtube.com/watch?v=Qc5IyLW_hns | — |

## Session 5 — Gradient boosting and XGBoost

| ★ | Video | Link | Length |
|---|---|---|---|
| ★★★ | Gradient Boost Part 1 (of 4): Regression Main Ideas | https://www.youtube.com/watch?v=3CC4N4z3GJc | 15:52 |
| ★★★ | Gradient Boost Part 3 (of 4): Classification | https://www.youtube.com/watch?v=jxuNLH5dXCs | — |
| ★★★ | XGBoost Part 1 (of 4): Regression | https://www.youtube.com/watch?v=OtD8wVaFm6E | 25:46 |
| ★★★ | XGBoost Part 2 (of 4): Classification | https://www.youtube.com/watch?v=8b1JEDvenQU | — |
| ★★ | Gradient Boost Part 2 (of 4): Regression Details | https://www.youtube.com/watch?v=2xudPOBz-vs | — |
| ★★ | Gradient Boost Part 4 (of 4): Classification Details | https://www.youtube.com/watch?v=StWY5QWMXCw | — |
| ★★ | XGBoost Part 3 (of 4): Mathematical Details | https://www.youtube.com/watch?v=ZVFeW798-2I | — |
| ★★ | XGBoost Part 4 (of 4): Crazy Cool Optimizations | https://www.youtube.com/watch?v=oRrKeUCEbq8 | — |
| ★ | AdaBoost, Clearly Explained | https://www.youtube.com/watch?v=LsK-xG1cLYA | 20:54 |

## Session 8 — Neural networks (watch these in order; the deck follows the same arc)

| ★ | Video | Link | Length |
|---|---|---|---|
| ★★★ | The Essential Main Ideas of Neural Networks | https://www.youtube.com/watch?v=CqOfi41LfDw | — |
| ★★★ | Neural Networks Pt. 2: Backpropagation Main Ideas | https://www.youtube.com/watch?v=IN2XmBhILt4 | 17:33 |
| ★★★ | The Chain Rule, Clearly Explained!!! | https://www.youtube.com/watch?v=wl1myxrtQHQ | — |
| ★★★ | Backpropagation Details Pt. 1: Optimizing 3 parameters simultaneously | https://www.youtube.com/watch?v=iyn2zdALii8 | 18:31 |
| ★★★ | Backpropagation Details Pt. 2: Going bonkers with The Chain Rule | https://www.youtube.com/watch?v=GKZoOHXGcLo | — |
| ★★★ | Neural Networks Pt. 3: ReLU In Action!!! | https://www.youtube.com/watch?v=68BZ5f7P94E | — |
| ★★★ | Neural Networks Pt. 4: Multiple Inputs and Outputs | https://www.youtube.com/watch?v=83LYR-1IcjA | 13:49 |
| ★★★ | Neural Networks Part 6: Cross Entropy | https://www.youtube.com/watch?v=6ArSys5qHAU | — |
| ★★ | Neural Networks Part 5: ArgMax and SoftMax | https://www.youtube.com/watch?v=KpKog-L9veg | — |
| ★★ | Neural Networks Part 7: Cross Entropy Derivatives and Backpropagation | https://www.youtube.com/watch?v=xBEh66V9gZo | ≥ 16:09 |
| ★★ | Neural Networks Part 8: Image Classification with Convolutional Neural Networks (CNNs) | https://www.youtube.com/watch?v=HGwBXDKFk9I | — |
| ★★ | Recurrent Neural Networks (RNNs), Clearly Explained!!! | https://www.youtube.com/watch?v=AsNTP8Kwu80 | — |
| ★★ | Transformer Neural Networks, ChatGPT's foundation, Clearly Explained!!! | https://www.youtube.com/watch?v=zxQyTK8quyY | 36:15 |
| ★ | The SoftMax Derivative, Step-by-Step!!! | https://www.youtube.com/watch?v=M59JElEPgIg | — |
| ★ | Long Short-Term Memory (LSTM), Clearly Explained | https://www.youtube.com/watch?v=YCzL96nL7j0 | 20:45 |
| ★ | Word Embedding and Word2Vec, Clearly Explained!!! | https://www.youtube.com/watch?v=viZrOnJclY0 | — |
| ★ | Mutual Information, Clearly Explained!!! | https://www.youtube.com/watch?v=eJIp_mgVLwE | — |

## How the videos map onto the materials

| Video(s) | Where it shows up |
|---|---|
| Bias & Variance; Cross Validation | Deck 01 (bias–variance curve), Deck 06, Tutorial 5 |
| Confusion Matrix; Sens & Spec; ROC & AUC | Deck 07, Tutorial 6 |
| Gradient Descent | Deck 05 ("why gradient"), Deck 08 §2, Tutorial 7 A6 |
| Decision Trees; Random Forests 1 | Deck 03 — the Gini worked example and the pictures are adapted from these |
| SVM 1–3 | Deck 04 — the threshold → margin → soft margin → kernel sequence is StatQuest's |
| Gradient Boost 1 & 3; XGBoost 1–2 | Deck 05, Tutorial 4 |
| Essential Main Ideas; Backprop Main Ideas; Backprop Details 1–2; Chain Rule | Deck 08 §1–2 and Tutorial 7 A3–A7 — the worked 2 → 2 → 1 example in the deck is a tabular cousin of StatQuest's hand-computed example |
| ReLU in Action; Multiple Inputs & Outputs; Cross Entropy | Deck 08 activations/loss slides, Tutorial 7 A4–A5 |
| CNNs; RNNs; Transformers | Deck 08 §6 "what deep learning adds", Tutorial 7 A11 |

Suggested schedule (≈ 1 h/evening): 4 Nov foundations · 5 Nov trees/forests + SVM · 6 Nov boosting/XGBoost ·
7–8 Nov neural networks (two evenings) · 9 Nov re-watch Backprop Details 1–2 with Tutorial 7 A7 open · 10 Nov
run `instructor/test_all.R` and read the facilitator notes.
