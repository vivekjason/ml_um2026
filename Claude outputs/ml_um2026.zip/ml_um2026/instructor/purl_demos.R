# =============================================================================
# instructor/purl_demos.R — regenerate demos/*.R (plain R scripts for live typing) from the tutorials.
# The tutorials are the single source of truth; run this after editing any tutorial.
#   source("instructor/purl_demos.R")
# =============================================================================
dir.create("demos", showWarnings = FALSE)
tuts <- list.files("tutorials", pattern = "\\.qmd$", full.names = TRUE)
for (f in tuts) {
  out <- file.path("demos", sub("\\.qmd$", ".R", basename(f)))
  knitr::purl(f, output = out, documentation = 1, quiet = TRUE)   # documentation = 1 keeps chunk labels as comments;
                                                                  # eval: false chunks come out commented
  lines <- readLines(out)
  writeLines(c(sprintf("# Extracted from %s by instructor/purl_demos.R - edit the tutorial, not this file.", f), "", lines), out)
  message("wrote ", out)
}
