# =============================================================================
# instructor/test_all.R  —  run EVERY piece of R code in the workshop (all seven tutorials + the take-home solution),
#                           in order, and report what broke.
#
# WHY: the materials were written against current tidymodels sources but could not be executed in the
# environment they were written in. This script is the test suite. Run it once on your own machine
# (20-40 minutes depending on cores; the SVM and kernelshap sections are the slow ones), then fix or
# report anything in the FAIL list.
#
# HOW:  open ml_um2026.Rproj, then in the console:   source("instructor/test_all.R")
#       A log is written to outputs/test_all_log.txt and a summary printed at the end.
# =============================================================================

stopifnot(file.exists("data/nhms_synthetic.csv"))      # are we in the project root?
dir.create("outputs", showWarnings = FALSE)

scripts <- c(
  "setup/check_setup.R",
  "R/prep_nhms.R",
  # demos/*.R are the tutorials' code, extracted chunk by chunk (data-raw/purl_demos.py; instructor/purl_demos.R
  # does the same with knitr::purl). Running them in order exercises every line of every tutorial INCLUDING the
  # collapsed solutions, and leaves the outputs/*.rds files the later tutorials read. NOTE: the first error in a
  # script aborts the rest of THAT script, so fix failures top-down - a failure in demos/05 means demos/06-07 fell
  # back to their fixed-spec XGBoost and their numbers will differ from a clean run.
  "demos/01_pipeline.R",
  "demos/02_random_forests.R",
  "demos/03_svm.R",
  "demos/04_xgboost.R",
  "demos/05_tuning.R",
  "demos/06_evaluation.R",
  "demos/07_neural_networks.R",
  "instructor/takehome_hpt_solution.R"
)

log_file <- "outputs/test_all_log.txt"
cat("test_all.R started", format(Sys.time()), "\n", file = log_file)
results <- data.frame(script = scripts, status = NA_character_, seconds = NA_real_, error = NA_character_, stringsAsFactors = FALSE)

# plots go to a PDF so nothing blocks on a graphics device
pdf("outputs/test_all_plots.pdf", width = 10, height = 7)

for (i in seq_along(scripts)) {
  s <- scripts[i]
  cat("\n==============================\n", s, "\n==============================\n")
  cat("\n==== ", s, " ====\n", file = log_file, append = TRUE)
  t0 <- Sys.time()
  res <- tryCatch({
    # each script in a fresh environment, output captured to the log; warnings logged but not fatal
    env <- new.env(parent = globalenv())
    out <- capture.output(
      withCallingHandlers(
        source(s, local = env, echo = FALSE, print.eval = TRUE),   # print.eval: ggplot/autoplot objects are only validated when printed
        warning = function(w) {
          cat("WARNING:", conditionMessage(w), "\n", file = log_file, append = TRUE)
          invokeRestart("muffleWarning")
        }
      ),
      type = "output"
    )
    cat(out, sep = "\n", file = log_file, append = TRUE)
    "PASS"
  }, error = function(e) {
    msg <- conditionMessage(e)
    cat("ERROR:", msg, "\n", file = log_file, append = TRUE)
    results$error[i] <<- msg
    "FAIL"
  })
  results$status[i]  <- res
  results$seconds[i] <- round(as.numeric(difftime(Sys.time(), t0, units = "secs")))
  cat(results$status[i], "in", results$seconds[i], "s\n")
}
dev.off()
if (requireNamespace("future", quietly = TRUE)) future::plan(future::sequential)   # shut the worker cluster down

cat("\n\n================ SUMMARY ================\n")
print(results[, c("script", "status", "seconds")], row.names = FALSE)
fails <- results[results$status == "FAIL", ]
if (nrow(fails)) {
  cat("\nFAILED SCRIPTS - first error message of each:\n")
  for (j in seq_len(nrow(fails))) cat("\n*", fails$script[j], "\n   ", fails$error[j], "\n")
  cat("\nFull log: outputs/test_all_log.txt  (search for 'ERROR')\n")
} else {
  cat("\nAll scripts ran without error. Plots are in outputs/test_all_plots.pdf - skim them for anything odd.\n")
}

# ---- render the site (tutorials + slides) into docs/ for GitHub Pages ------------------------------
# Uncomment after the scripts pass. Needs Quarto >= 1.4 on the PATH. First render: 20-40 min (the tutorials
# execute their code); later renders re-run only changed files (freeze: auto).
# system("quarto render")
