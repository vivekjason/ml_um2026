# Facilitator notes — Predictive Intelligence in R, 11–12 Nov 2026

## The shape of the thing

Eight sessions, four model families (random forest, SVM, XGBoost, neural network), logistic regression as the
baseline only. **Each session = short lecture (deck) → live coding from the tutorial → "Your turn" in the
tutorial.** The tutorials (`tutorials/01–07.qmd`) are the single source of truth: they contain all the code, the
expected output once rendered, the exercises and the collapsed solutions, and they are what goes on GitHub Pages.
`demos/*.R` are the same code extracted to plain scripts for live typing (regenerate with
`instructor/purl_demos.R` after editing a tutorial). There is no capstone; a take-home challenge closes Tutorial 7.

## Before the workshop

| When | Do |
|---|---|
| Now | Watch the ★★★ videos in `instructor/statquest_watchlist.md` (≈ 5–6 h). The decks' pictures and worked examples follow them. |
| Now | `source("instructor/test_all.R")` on your laptop (20–40 min). Fix/report anything in the FAIL list. |
| Then | `quarto render` → open `docs/index.html`. Push `docs/` to GitHub; Settings → Pages → *Deploy from a branch* → `main` / `docs`. The tutorials with outputs are now the participants' reference. |
| Decide | torch/brulee **in** or **out** (Tutorial 7 C4). If fewer than half the room pre-installs torch, run it from your laptop only; nothing downstream depends on it. |
| −7 days | Send `setup/participant_email.md` with the repo/zip link. |
| −2 days | Resend: "reply with your `check_setup.R` output". Triage. |
| −1 day | Run the seven demos end-to-end on the machine you will project from; the `outputs/*.rds` they leave are your safety net (Tutorials 6 and 7 fall back to them). Time the SVM and kernelshap chunks on *that* machine. |
| −1 day | Recruit two helpers; give them the rendered tutorials (solutions are in there, collapsed). |

## Room and pacing

- RStudio font 18+, `Tools > Global Options > Appearance`; `Console > Limit output`; **`Tools > Global Options >
  R Markdown > Evaluate chunks in directory = Project`** (otherwise interactive chunks run from `tutorials/` and
  `data/...` paths fail — this is in the participant setup too, and the first thing to check at the setup clinic).
  Open the tutorial `.qmd` and run chunks with Ctrl+Shift+Enter — participants do the same.
- Every chunk in the tutorials has a label (`#| label:`); say the label out loud when you jump.
- **If behind:** every *Your turn* is self-contained and can be finished at home. Protect the live coding and, on
  Day 2, the NN theory block (Deck 08 §1–3) — it is what people came for and the hardest to self-teach.
- **If ahead:** the stretch tasks; `tune_bayes()` (Tutorial 5); decision curves (Tutorial 6); the brulee
  stretch tasks (Tutorial 7 C).
- Tea breaks are 20 min because people need 5 of them to get their code running again.

## Session-by-session

### Day 1

**09.00 Deck 01.** Poll the room (slide 2). The synthetic-data slide is deliberate — say it plainly. The "what
changed since 2023" slide matters for anyone holding your 2023 notes: `select_best(res, "roc_auc")` is now an
*error*, `doParallel` silently does nothing.

**10.50 Deck 02 + Tutorial 1.** The arc is naive model → AUC 0.98 → `tidy()` shows `rbs` → leakage → honest model
→ ~0.85. Let them *see* the 0.98 before you explain it; ask "is this good news?". Expect two or three people to
argue `rbs` is a legitimate predictor — that is the teaching moment: "when would you have it, and what would you do
with the model once you did?". The `pa`/`pa_3cat` duplicate is in Task A: `count(nhms, pa, pa_3cat)` settles it.

**12.00 Your turn 1.** Common stalls: `step_indicate_na()` after imputation (nothing left to indicate);
`step_impute_knn()` is slow-ish (1–2 min) — fine. Debrief Q2 (impute before split → optimistic) is the one most
people get wrong.

**14.00 Deck 03 + Tutorial 2.** Gini worked example on the slides is the only arithmetic of the day. The
train/test gap of the unpruned tree: make them say both numbers aloud. Task A is 2023's exercise redone on folds —
the finding is that all four forests tie, which is the point (forests are forgiving → tune XGBoost instead).

**15.50 Deck 04 + Tutorial 3.** SVM is deliberately the shortest family. Watch the clock on the three-kernel
`workflow_map()` — the polynomial kernel with Platt scaling is the slow one; if the projector laptop is weak, run
only linear + RBF live. Task A (cost vs overfitting) is the one to protect; Task B (no scaling) is a 3-minute
dramatic failure.

**17.00 Wrap.** Three sentences: leak, resample, four families tomorrow. Mention Tutorial 4 can be read tonight.

### Day 2

**09.15 Deck 05 + Tutorial 4.** Defaults vs gentle: if the gap on your machine is small (< 0.01) say so — the point
is *sensitivity to settings*. The early-stopping plot (three learning-rate curves) is the slide that makes "learning
rate vs trees" stick; it comes back at 14.00 as gradient descent. The bake-off object is reused all day — make sure
`outputs/t04_bakeoff_res.rds` is written.

**10.50 Deck 06 + Tutorial 5.** The 25-splits histogram is the most important plot of the day. Racing: watch the
`verbose_elim` output together. Show `select_best()` and `select_by_one_std_err()` disagreeing on the grid object.
The test set is touched for the first time in §5 — say so.

**11.50 Deck 07 + Tutorial 6.** Order matters: decisions (confusion matrix, prevalence) → probabilities (ROC/PR,
Brier, calibration) → threshold → imbalance → explain. The SMOTE comparison lands hard with clinicians: sensitivity
up, Brier worse, AUC unchanged. kernelshap on 300 × 100 rows takes 1–3 min on 4 cores — start it, then talk through
the DALEX plots while it runs.

**14.00 Deck 08 (55 min) + Tutorial 7 Part B.** The deck's spine is the **worked 2 → 2 → 1 example**: forward pass
(slide "keep these numbers"), then backprop steps 1–3 with the same numbers, then one gradient-descent step and the
loss falling from 0.5154 to 0.3615. Write the numbers on the whiteboard as you go; Tutorial 7 A3–A7 has the same
numbers so people can follow at their own pace. Then Part B live: run the loop, show `W1` before and after, the loss
curve, the four boundary panels. Ask "where is the learning?" — answer: in `W1` and `W2`, nowhere else.

**15.50 Tutorial 7 Part C.** `mlp()` is anticlimactic by design — same six verbs. The tabular-data verdict slide is
reassurance, not anti-NN: on this data a tie is the honest result. If torch is not in the room, skip C4 and say why.

**16.40 Deck 09.** Fill the verdict table from `outputs/t07_verdict.rds`. The reveal slide: ask who found the
family-history × BMI bands and the two waist curves in their SHAP plots. Close on the ten rules and the take-home.

## Known gotchas (and the fix)

| Symptom | Cause | Fix |
|---|---|---|
| `select_best(): ... must be empty` | positional metric name | `metric = "roc_auc"` |
| tuning not using multiple cores | tune ≥ 1.3 ignores foreach | `library(future); plan(multisession, workers = n)` |
| `source("R/prep_nhms.R")` not found when rendering | Quarto ran the chunk from `tutorials/` | `execute-dir: project` is set in `_quarto.yml`; don't remove it |
| xgboost error about non-numeric predictors | recipe without `step_dummy()` | use `dm_rec`, not `tree_rec`, for xgboost |
| nnet: "too many (…) weights" | default `MaxNWts = 1000` | `set_engine("nnet", MaxNWts = 10000)` |
| brulee: torch not installed / prompts to download | first use | `torch::install_torch()` before the workshop; skip C4 otherwise |
| `kernelshap` very slow | too many rows / background | 200–300 rows, 50–100 background; trees fast, SVM slow |
| DALEX plots show `.pred_No` behaviour | default target column is the 2nd level | `predict_function_target_column = "Yes"` |
| sens/spec look swapped | outcome levels `c("No","Yes")` | relevel so `"Yes"` is first (or `event_level = "second"`) |
| `cal_validate_logistic()` errors | resample object without predictions | `control_resamples(save_pred = TRUE)` |
| `step_smote()` errors on NA / factors | SMOTE needs numeric, complete data | put it **after** impute + dummy + normalize |
| glm: "prediction from rank-deficient fit" | both `pa` and `pa_3cat` kept (exact recode) | drop `pa`, or `step_lincomb(all_numeric_predictors())` after `step_zv()` |
| evaluation log missing from xgboost fit | no validation slice | `set_engine("xgboost", validation = 0.2)` + `stop_iter` |

## What was and was not verified before hand-over

- **Verified**: the data generation and its signal structure (Python, sklearn cross-validation); the worked
  backpropagation numbers (computed independently); every tidymodels / probably / finetune / DALEXtra /
  kernelshap / shapviz / brulee / xgboost function signature against the current CRAN sources (Oct–Nov 2026); the
  StatQuest links against the official index; an independent static review of the R code.
- **Not executed**: the R code itself — no R was available where the materials were written.
  `instructor/test_all.R` exists for exactly this reason. Expect small things (a plot method's default, a renamed
  argument in a point release), not structural problems.
- The expected numbers quoted in the tutorials (honest AUC ≈ 0.85, leaky ≈ 0.98, take-home ≈ 0.82) come from
  sklearn equivalents on the same data and should be within ±0.02 of what R produces. The narrative never hard-codes
  an output; the rendered pages will show the real ones.
