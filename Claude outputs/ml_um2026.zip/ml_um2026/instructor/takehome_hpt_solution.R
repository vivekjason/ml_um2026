# =============================================================================
# Take-home challenge · model solution (instructor): who has undiagnosed hypertension?
# Expected honest test AUC ~0.81-0.83, Brier ~0.13. "Measure one in three" -> sens ~0.65-0.70, PPV ~0.45-0.50.
# =============================================================================
source("R/prep_nhms.R")
library(finetune); library(probably); library(kernelshap); library(shapviz); library(future)
plan(multisession, workers = max(1, parallel::detectCores() - 1))
dir.create("outputs", showWarnings = FALSE)

# 1. leakage audit -----------------------------------------------------------------
nhms |> count(undx_hpt) |> mutate(prop = n / sum(n))                       # ~23%
# sys/dys: NO - they DEFINE the outcome. rbs/rchol: NO - lab values, not available pre-test, define the other outcomes.
# undx_dm/undx_chol: NO - other screening outcomes from the same visit. dm/hpt/chol: all zero. id: identifier.
# pa: duplicate of pa_3cat. bmi/waist/fam_hx_hpt: YES - tape measure + one question.
hpt_data <- nhms |> select(-id, -undx_dm, -undx_chol, -sys, -dys, -rbs, -rchol, -pa)

# 2. split / folds / recipe ----------------------------------------------------------
set.seed(2026)
hpt_split <- initial_split(hpt_data, prop = 0.80, strata = undx_hpt)
hpt_train <- training(hpt_split); hpt_test <- testing(hpt_split)
set.seed(2026)
hpt_folds <- vfold_cv(hpt_train, v = 5, strata = undx_hpt)
hpt_rec <- recipe(undx_hpt ~ ., data = hpt_train) |>
  step_impute_median(all_numeric_predictors()) |> step_impute_mode(all_nominal_predictors()) |>
  step_dummy(all_nominal_predictors()) |> step_zv(all_predictors()) |> step_normalize(all_numeric_predictors())

# 3. bake-off ---------------------------------------------------------------------------
zoo <- list(
  logistic = logistic_reg() |> set_engine("glm"),
  rf       = rand_forest(trees = 500, mtry = 6, min_n = 10) |> set_engine("ranger") |> set_mode("classification"),
  svm_rbf  = svm_rbf(cost = 1, rbf_sigma = 0.005) |> set_engine("kernlab") |> set_mode("classification"),
  xgb      = boost_tree(trees = 500, learn_rate = 0.03, tree_depth = 3, min_n = 20) |> set_engine("xgboost") |> set_mode("classification"),
  nnet     = mlp(hidden_units = 8, penalty = 0.01, epochs = 150) |> set_engine("nnet", MaxNWts = 10000) |> set_mode("classification")
)
set.seed(2026)
bake_res <- workflow_set(preproc = list(base = hpt_rec), models = zoo) |>
  workflow_map("fit_resamples", resamples = hpt_folds, metrics = cls_metrics, seed = 2026, verbose = TRUE)
rank_results(bake_res, rank_metric = "roc_auc", select_best = TRUE) |>
  filter(.metric %in% c("roc_auc", "brier_class")) |> select(wflow_id, .metric, mean, std_err)
# rf / xgb / logistic within ~1 SE (0.81-0.83); nnet close behind; svm similar.

# 4. race-tune the winner (xgb) ----------------------------------------------------------
tune_wf <- workflow(hpt_rec, boost_tree(trees = 500, learn_rate = tune(), tree_depth = tune(), min_n = tune()) |>
                      set_engine("xgboost") |> set_mode("classification"))
tune_params <- extract_parameter_set_dials(tune_wf) |>
  update(learn_rate = learn_rate(range = c(-2.5, -0.5)), tree_depth = tree_depth(range = c(2L, 8L)), min_n = min_n(range = c(5L, 60L)))
set.seed(2026)
race <- tune_race_anova(tune_wf, hpt_folds, param_info = tune_params, grid = 12,
                        metrics = metric_set(roc_auc, brier_class), control = control_race(verbose_elim = TRUE, save_pred = TRUE))
show_best(race, metric = "roc_auc", n = 3)
final_wf <- finalize_workflow(tune_wf, select_best(race, metric = "roc_auc"))

# 5. threshold for "measure one in three", on CV predictions ------------------------------
cv_preds <- collect_predictions(race, parameters = select_best(race, metric = "roc_auc"))
grid_t <- seq(0.05, 0.80, by = 0.01)
flag_rate <- map_dbl(grid_t, \(t) mean(cv_preds$.pred_Yes >= t))
thr_chosen <- grid_t[which.min(abs(flag_rate - 1 / 3))]
thr_chosen                                                                 # ~0.25-0.30
threshold_perf(cv_preds, undx_hpt, .pred_Yes, thresholds = thr_chosen)   # sens ~0.65-0.70, spec ~0.77

# 6. test set, once ---------------------------------------------------------------------
final_last <- last_fit(final_wf, hpt_split, metrics = cls_metrics)
collect_metrics(final_last)
test_preds <- collect_predictions(final_last)
test_rule <- test_preds |>
  mutate(.pred_rule = make_two_class_pred(.pred_Yes, levels = levels(undx_hpt), threshold = thr_chosen) |> as.factor())
test_rule |> summarise(flagged_pct = mean(.pred_rule == "Yes"),
                       sens = sum(.pred_rule == "Yes" & undx_hpt == "Yes") / sum(undx_hpt == "Yes"),
                       spec = sum(.pred_rule == "No"  & undx_hpt == "No")  / sum(undx_hpt == "No"),
                       ppv  = sum(.pred_rule == "Yes" & undx_hpt == "Yes") / sum(.pred_rule == "Yes"),
                       nnm  = 1 / ppv)
# "Measuring the BP of the ~33% of adults the model flags finds ~65-70% of undiagnosed cases; about two people measured per case found."
cal_plot_breaks(test_preds, truth = undx_hpt, estimate = .pred_Yes)

# 7. explain ----------------------------------------------------------------------------
final_fit <- extract_workflow(final_last)
pred_yes  <- function(model, newdata, ...) predict(model, newdata, type = "prob")$.pred_Yes
set.seed(2026)
X_explain <- hpt_train |> select(-undx_hpt) |> slice_sample(n = 200)
X_bg      <- hpt_train |> select(-undx_hpt) |> slice_sample(n = 80)
sv <- kernelshap(final_fit, X = X_explain, bg_X = X_bg, pred_fun = pred_yes, verbose = FALSE) |> shapviz()
sv_importance(sv, kind = "beeswarm", max_display = 12)      # age, fam_hx_hpt, bmi/waist, sex, alcohol/smoke
sv_dependence(sv, v = "age", color_var = "sex")              # women's risk catches up after ~55 (planted)
sv_dependence(sv, v = "bmi", color_var = "fam_hx_hpt")       # family history x obesity (planted)
sv_waterfall(sv, row_id = which.max(pred_yes(final_fit, X_explain)))

# 8. caveats (model answers) ------------------------------------------------------------
#  - Validated at 23% prevalence; PPV falls in a lower-prevalence district (report sens/spec; recompute PPV).
#  - Synthetic data: plausible structure, not estimates of anything.
#  - SHAP describes the model, not biology; correlated anthropometrics share credit.
#  - TRIPOD+AI would still ask for: external validation, calibration by subgroup, fairness by ethnicity/sex,
#    missing-data handling at deployment, decision-curve analysis.

# THE REVEAL: planted for undx_hpt in data-raw/simulate_nhms_synthetic.py - women >= 55; fam_hx_hpt x BMI >= 30;
# alcohol x current smoking; central obesity x inactivity (sex-specific waist cut-offs); Indian x age >= 45.
saveRDS(final_last, "outputs/takehome_hpt_last.rds")
