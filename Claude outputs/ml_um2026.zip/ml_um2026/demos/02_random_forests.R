# =============================================================================
# Tutorial 2 · Decision trees and random forests
# Extracted from tutorials/02_random_forests.qmd - the tutorial is the source of truth (instructor/purl_demos.R regenerates this).
# Run chunk by chunk with Ctrl+Enter. '## ----' lines are the tutorial's chunk labels.
# =============================================================================


# ---- What you will do ------------------------------------------------------


# ---- 0 · Start where Tutorial 1 ended --------------------------------------

## ---- setup ----
source("R/prep_nhms.R")   # nhms, dm_data, dm_split, dm_train, dm_test, dm_folds, dm_rec, cls_metrics
library(rpart.plot)
library(vip)
library(future)
plan(multisession, workers = max(1, parallel::detectCores() - 1))   # resampling will use all cores


# ---- 1 · One decision tree -------------------------------------------------


# ---- In one paragraph ------------------------------------------------------

## ---- tree-rec ----
tree_rec <- recipe(undx_dm ~ ., data = dm_train) |>
  step_impute_median(all_numeric_predictors()) |>
  step_impute_mode(all_nominal_predictors()) |>
  step_zv(all_predictors())


# ---- A small, pruned tree --------------------------------------------------

## ---- tree-small ----
tree_small <- decision_tree(cost_complexity = 0.005, tree_depth = 4, min_n = 20) |>
  set_engine("rpart") |>
  set_mode("classification")

tree_small_fit <- workflow(tree_rec, tree_small) |> fit(dm_train)
tree_small_fit |> extract_fit_engine() |> rpart.plot(roundint = FALSE, extra = 104, type = 2)


# ---- An unconstrained tree — the overfitting signature ---------------------

## ---- tree-big ----
tree_big <- decision_tree(cost_complexity = 0, tree_depth = 30, min_n = 2) |>
  set_engine("rpart") |>
  set_mode("classification")
tree_big_fit <- workflow(tree_rec, tree_big) |> fit(dm_train)

bind_rows(
  small_train = augment(tree_small_fit, dm_train) |> roc_auc(undx_dm, .pred_Yes),
  small_test  = augment(tree_small_fit, dm_test)  |> roc_auc(undx_dm, .pred_Yes),
  big_train   = augment(tree_big_fit,   dm_train) |> roc_auc(undx_dm, .pred_Yes),
  big_test    = augment(tree_big_fit,   dm_test)  |> roc_auc(undx_dm, .pred_Yes),
  .id = "model"
)


# ---- 2 · Random forest: many noisy trees, averaged -------------------------


# ---- In one paragraph ------------------------------------------------------

## ---- rf-spec ----
rf_spec <- rand_forest(trees = 500, mtry = 6, min_n = 10) |>
  set_engine("ranger", importance = "permutation", seed = 2026) |>
  set_mode("classification")

rf_wf <- workflow(tree_rec, rf_spec)


# ---- Honest estimate: 5-fold cross-validation on the training set ----------

## ---- rf-cv ----
set.seed(2026)
rf_res <- fit_resamples(rf_wf, resamples = dm_folds, metrics = cls_metrics,
                        control = control_resamples(save_pred = TRUE))
collect_metrics(rf_res)


# ---- Fit once on all the training data, and look inside --------------------

## ---- rf-fit ----
rf_fit <- fit(rf_wf, dm_train)
rf_fit |> extract_fit_engine()      # note "OOB prediction error (Brier s.)" - a free validation estimate

## ---- rf-vip ----
rf_fit |> extract_fit_parsnip() |> vip(num_features = 15) +
  labs(title = "Random forest: permutation importance",
       subtitle = "How much the OOB error rises when this column is shuffled")


# ---- Compared with this morning's baseline ---------------------------------

## ---- rf-vs-lr ----
lr_wf <- workflow(dm_rec, logistic_reg() |> set_engine("glm"))
set.seed(2026)
lr_res <- fit_resamples(lr_wf, dm_folds, metrics = cls_metrics)

bind_rows(logistic = collect_metrics(lr_res), random_forest = collect_metrics(rf_res), .id = "model") |>
  filter(.metric %in% c("roc_auc", "pr_auc", "brier_class")) |>
  ggplot(aes(x = mean, y = model, colour = model)) +
  geom_pointrange(aes(xmin = mean - std_err, xmax = mean + std_err), show.legend = FALSE) +
  facet_wrap(~ .metric, scales = "free_x") +
  labs(x = "5-fold CV estimate (± 1 SE)", y = NULL, title = "Same folds, same recipe idea, two model families")


# ---- Your turn (25 min) ----------------------------------------------------


# ---- Task A · The five-minute forest (the 2023 exercise, done honestly) ----

## ---- taskA (YOUR TURN: fill the blanks; not run as-is) ----
# forests <- list(
#   heuristic = rand_forest(mtry = 6,   trees = 500,  min_n = 10) |> set_engine("ranger") |> set_mode("classification"),
#   model_1   = rand_forest(mtry = ___, trees = ___,  min_n = ___) |> set_engine("ranger") |> set_mode("classification"),   # TUNE
#   model_2   = rand_forest(mtry = ___, trees = ___,  min_n = ___) |> set_engine("ranger") |> set_mode("classification"),   # TUNE
#   model_3   = rand_forest(mtry = ___, trees = ___,  min_n = ___) |> set_engine("ranger") |> set_mode("classification")    # TUNE
# )
# 
# set.seed(2026)
# forest_res <- workflow_set(preproc = list(tree = tree_rec), models = forests) |>
#   workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026, verbose = TRUE)
# 
# rank_results(forest_res, rank_metric = "roc_auc", select_best = TRUE) |>
#   filter(.metric %in% c("roc_auc", "brier_class")) |>
#   select(wflow_id, .metric, mean, std_err)


# ---- Solution A ------------------------------------------------------------

## ---- solA ----
forests <- list(
  heuristic = rand_forest(mtry = 6,  trees = 500,  min_n = 10) |> set_engine("ranger") |> set_mode("classification"),
  wide      = rand_forest(mtry = 15, trees = 500,  min_n = 10) |> set_engine("ranger") |> set_mode("classification"),
  deep      = rand_forest(mtry = 6,  trees = 500,  min_n = 2)  |> set_engine("ranger") |> set_mode("classification"),
  smooth    = rand_forest(mtry = 4,  trees = 1000, min_n = 40) |> set_engine("ranger") |> set_mode("classification")
)
set.seed(2026)
forest_res <- workflow_set(preproc = list(tree = tree_rec), models = forests) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026)

rank_results(forest_res, rank_metric = "roc_auc", select_best = TRUE) |>
  filter(.metric %in% c("roc_auc", "brier_class")) |>
  select(wflow_id, .metric, mean, std_err)


# ---- Task B · Does the forest see the same world as the GLM? (10 min) ------


# ---- Solution B ------------------------------------------------------------

## ---- solB ----
lr_fit <- fit(lr_wf, dm_train)
tidy(lr_fit) |> filter(term != "(Intercept)") |> arrange(desc(abs(statistic))) |> select(term, estimate, statistic) |> head(10)
rf_fit |> extract_fit_parsnip() |> vi() |> head(10)


# ---- Task C · Stretch ------------------------------------------------------


# ---- Solution C ------------------------------------------------------------


# ---- What to remember ------------------------------------------------------

