# =============================================================================
# Tutorial 4 · Gradient boosting with XGBoost — and the bake-off
# Extracted from tutorials/04_xgboost.qmd - the tutorial is the source of truth (instructor/purl_demos.R regenerates this).
# Run chunk by chunk with Ctrl+Enter. '## ----' lines are the tutorial's chunk labels.
# =============================================================================


# ---- What you will do ------------------------------------------------------


# ---- 0 · Start -------------------------------------------------------------

## ---- setup ----
source("R/prep_nhms.R")
library(future)
plan(multisession, workers = max(1, parallel::detectCores() - 1))
dir.create("outputs", showWarnings = FALSE)


# ---- 1 · Boosting in one paragraph -----------------------------------------


# ---- 2 · "Just use the defaults" vs a gentle setting -----------------------

## ---- default-vs-gentle ----
xgb_default <- boost_tree(trees = 500, learn_rate = 0.3, tree_depth = 6) |>      # xgboost's own defaults
  set_engine("xgboost") |> set_mode("classification")

xgb_gentle <- boost_tree(trees = 500, learn_rate = 0.03, tree_depth = 3, min_n = 20,
                         sample_size = 0.8, mtry = 0.7, loss_reduction = 1) |>
  set_engine("xgboost", counts = FALSE) |> set_mode("classification")

set.seed(2026)
xgb_two <- workflow_set(preproc = list(base = dm_rec), models = list(default = xgb_default, gentle = xgb_gentle)) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026)

collect_metrics(xgb_two) |> filter(.metric %in% c("roc_auc", "brier_class")) |> select(wflow_id, .metric, mean, std_err)


# ---- 3 · Learning rate and number of trees trade off: early stopping -------

## ---- early-stopping ----
fit_with_stop <- function(lr) {
  spec <- boost_tree(trees = 2000, learn_rate = lr, tree_depth = 3, min_n = 20, stop_iter = 25) |>
    set_engine("xgboost", validation = 0.2) |>
    set_mode("classification")
  set.seed(2026)
  workflow(dm_rec, spec) |> fit(dm_train) |> extract_fit_engine()
}

# the evaluation log lives in different places in xgboost 1.x and >= 2.x; this reads both
eval_log <- function(booster) {
  log <- attributes(booster)$evaluation_log
  if (is.null(log)) log <- tryCatch(booster$evaluation_log, error = function(e) NULL)
  as_tibble(log)
}

curves <- purrr::map_dfr(c(0.3, 0.05, 0.01), \(lr) fit_with_stop(lr) |> eval_log() |> mutate(learn_rate = lr))

curves |>
  ggplot(aes(iter, validation_logloss, colour = factor(learn_rate))) +
  geom_line(linewidth = 1) +
  labs(x = "number of trees", y = "validation log-loss", colour = "learn_rate",
       title = "Early stopping: where each learning rate stops improving") +
  theme_minimal()

curves |> group_by(learn_rate) |> summarise(best_iter = iter[which.min(validation_logloss)], best_logloss = min(validation_logloss))


# ---- 4 · XGBoost handles missing values itself -----------------------------

## ---- native-na ----
rec_native_na <- recipe(undx_dm ~ ., data = dm_train) |>
  step_dummy(all_nominal_predictors()) |>    # NA in a factor becomes NA in every dummy column - xgboost copes
  step_zv(all_predictors())

set.seed(2026)
xgb_na <- workflow_set(preproc = list(imputed = dm_rec, native_na = rec_native_na), models = list(xgb = xgb_gentle)) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026)
collect_metrics(xgb_na) |> filter(.metric %in% c("roc_auc", "brier_class")) |> select(wflow_id, .metric, mean, std_err)


# ---- 5 · The bake-off: four families, same folds, one object ---------------

## ---- bakeoff ----
model_zoo <- list(
  logistic = logistic_reg() |> set_engine("glm"),
  rf       = rand_forest(trees = 500, mtry = 6, min_n = 10) |> set_engine("ranger") |> set_mode("classification"),
  svm_rbf  = svm_rbf(cost = 1, rbf_sigma = 0.005) |> set_engine("kernlab") |> set_mode("classification"),
  xgb      = xgb_gentle
)

bakeoff <- workflow_set(preproc = list(base = dm_rec), models = model_zoo)
bakeoff

set.seed(2026)
bakeoff_res <- bakeoff |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026, verbose = TRUE,
               control = control_resamples(save_pred = TRUE))

rank_results(bakeoff_res, rank_metric = "roc_auc", select_best = TRUE) |>
  filter(.metric %in% c("roc_auc", "pr_auc", "brier_class")) |>
  select(wflow_id, .metric, mean, std_err, rank)

autoplot(bakeoff_res, metric = c("roc_auc", "brier_class")) + theme_minimal()

## ---- roc-all ----
collect_predictions(bakeoff_res) |>
  group_by(wflow_id) |>
  roc_curve(undx_dm, .pred_Yes) |>
  autoplot()

## ---- save ----
saveRDS(bakeoff_res, "outputs/t04_bakeoff_res.rds")     # kept so you can reload it without re-running (nothing later requires it)


# ---- Your turn (15 min) ----------------------------------------------------


# ---- Task A · The five-minute XGBoost (the 2023 exercise, done honestly) ---

## ---- taskA (YOUR TURN: fill the blanks; not run as-is) ----
# boosters <- list(
#   gentle  = xgb_gentle,
#   model_1 = boost_tree(trees = ___, learn_rate = ___, tree_depth = ___, min_n = ___) |> set_engine("xgboost") |> set_mode("classification"),
#   model_2 = boost_tree(trees = ___, learn_rate = ___, tree_depth = ___, min_n = ___) |> set_engine("xgboost") |> set_mode("classification"),
#   model_3 = boost_tree(trees = ___, learn_rate = ___, tree_depth = ___, min_n = ___) |> set_engine("xgboost") |> set_mode("classification")
# )
# set.seed(2026)
# boost_res <- workflow_set(preproc = list(base = dm_rec), models = boosters) |>
#   workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026, verbose = TRUE)
# rank_results(boost_res, rank_metric = "roc_auc", select_best = TRUE) |>
#   filter(.metric %in% c("roc_auc", "brier_class")) |> select(wflow_id, .metric, mean, std_err)


# ---- Solution A ------------------------------------------------------------

## ---- solA ----
boosters <- list(
  gentle   = xgb_gentle,
  slow_deep = boost_tree(trees = 1000, learn_rate = 0.01, tree_depth = 6, min_n = 10) |> set_engine("xgboost") |> set_mode("classification"),
  stumps    = boost_tree(trees = 1000, learn_rate = 0.05, tree_depth = 1, min_n = 20) |> set_engine("xgboost") |> set_mode("classification"),
  fast      = boost_tree(trees = 200,  learn_rate = 0.3,  tree_depth = 3, min_n = 20) |> set_engine("xgboost") |> set_mode("classification")
)
set.seed(2026)
boost_res <- workflow_set(preproc = list(base = dm_rec), models = boosters) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026)
rank_results(boost_res, rank_metric = "roc_auc", select_best = TRUE) |>
  filter(.metric %in% c("roc_auc", "brier_class")) |> select(wflow_id, .metric, mean, std_err)


# ---- Task B · Monotone constraints (stretch) -------------------------------


# ---- Solution B ------------------------------------------------------------

## ---- solB ----
pred_names <- dm_rec |> prep() |> bake(new_data = NULL) |> select(-undx_dm) |> names()
mono <- as.integer(pred_names == "age")      # one entry per predictor column, in recipe order: +1 for age, 0 for the rest

xgb_mono <- boost_tree(trees = 500, learn_rate = 0.03, tree_depth = 3, min_n = 20) |>
  set_engine("xgboost", monotone_constraints = mono) |> set_mode("classification")

set.seed(2026)
mono_res <- fit_resamples(workflow(dm_rec, xgb_mono), dm_folds, metrics = cls_metrics)
collect_metrics(mono_res) |> filter(.metric %in% c("roc_auc", "brier_class"))


# ---- What to remember ------------------------------------------------------

