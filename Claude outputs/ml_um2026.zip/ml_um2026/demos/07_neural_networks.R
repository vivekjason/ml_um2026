# =============================================================================
# Tutorial 7 · Neural networks
# Extracted from tutorials/07_neural_networks.qmd - the tutorial is the source of truth (instructor/purl_demos.R regenerates this).
# Run chunk by chunk with Ctrl+Enter. '## ----' lines are the tutorial's chunk labels.
# =============================================================================


# ---- What you will do ------------------------------------------------------


# ---- Part A · Theory primer ------------------------------------------------


# ---- A1 · You already own a neural network ---------------------------------


# ---- A2 · Why one neuron is not enough -------------------------------------


# ---- A3 · The multilayer perceptron (MLP) ----------------------------------


# ---- A worked forward pass (keep these numbers; we reuse them for backpropagation) 


# ---- A4 · Activation functions: the non-linearity is the point -------------


# ---- A5 · The loss: what "wrong" means -------------------------------------


# ---- A6 · Gradient descent: walking downhill -------------------------------


# ---- A7 · Backpropagation is the chain rule --------------------------------


# ---- In matrix form, for $n$ people (this is Part B's code) ----------------

## ---- worked-example-check ----
sigmoid <- function(z) 1 / (1 + exp(-z))
x <- c(1, 0.5); y <- 1
W1 <- matrix(c(0.5, 0.2, -0.3, 0.8), nrow = 2); b1 <- c(0.1, 0.1); W2 <- c(0.7, -0.4); b2 <- 0.05
z1 <- as.vector(x %*% W1) + b1; a1 <- tanh(z1); z2 <- sum(W2 * a1) + b2; p <- sigmoid(z2)
c(z1 = z1, a1 = a1, z2 = z2, p = p, loss = -log(p))
d2 <- p - y; dW2 <- d2 * a1; db2 <- d2
d1 <- (d2 * W2) * (1 - a1^2); dW1 <- outer(x, d1); db1 <- d1
list(dW2 = dW2, dW1 = dW1)
lr <- 0.5
W1 <- W1 - lr * dW1; b1 <- b1 - lr * db1; W2 <- W2 - lr * dW2; b2 <- b2 - lr * db2
z1 <- as.vector(x %*% W1) + b1; a1 <- tanh(z1); p_new <- sigmoid(sum(W2 * a1) + b2)
c(p_after_one_step = p_new, loss_after = -log(p_new))


# ---- A8 · Making training work: initialisation and gradient flow -----------


# ---- A9 · Capacity, overfitting and the brakes -----------------------------


# ---- A10 · Architecture choices for tabular data ---------------------------


# ---- A11 · Beyond the MLP (what "deep learning" adds) ----------------------


# ---- A12 · When neural networks lose: the evidence on tabular data ---------


# ---- A13 · How deep learning fails in health (same medicine as Day 1) ------


# ---- A14 · Glossary --------------------------------------------------------


# ---- Part B · A network from scratch (base R, no packages) -----------------

## ---- setup ----
source("R/prep_nhms.R")
library(finetune)
library(kernelshap)
library(shapviz)
library(patchwork)
library(future)
plan(multisession, workers = max(1, parallel::detectCores() - 1))
dir.create("outputs", showWarnings = FALSE)


# ---- B1 · A problem a straight line cannot solve ---------------------------

## ---- toy ----
set.seed(42)
n  <- 300
r  <- c(runif(n / 2, 0, 1.0), runif(n / 2, 1.6, 2.6))
th <- runif(n, 0, 2 * pi)
X  <- cbind(r * cos(th), r * sin(th)) + matrix(rnorm(2 * n, 0, 0.15), n, 2)
y  <- matrix(c(rep(1, n / 2), rep(0, n / 2)), ncol = 1)
toy <- tibble(x1 = X[, 1], x2 = X[, 2], class = factor(ifelse(y == 1, "inner", "outer"), levels = c("inner", "outer")))

ggplot(toy, aes(x1, x2, colour = class)) + geom_point(size = 2) + coord_equal() + theme_minimal() +
  labs(title = "Can one straight line separate these?")

glm_toy <- glm(class ~ x1 + x2, data = toy, family = binomial)
mean((predict(glm_toy, type = "response") > 0.5) == (toy$class == "outer"))    # logistic regression: a coin flip


# ---- B2 · The network: 2 inputs → 8 tanh units → 1 sigmoid output ----------

## ---- scratch-net ----
sigmoid <- function(z) 1 / (1 + exp(-z))
H  <- 8          # hidden units
lr <- 0.5        # learning rate

set.seed(1)
W1 <- matrix(rnorm(2 * H, sd = 0.5), nrow = 2, ncol = H); b1 <- rep(0, H)   # input  -> hidden
W2 <- matrix(rnorm(H, sd = 0.5), nrow = H, ncol = 1);     b2 <- 0           # hidden -> output

forward <- function(X, W1, b1, W2, b2) {
  Z1 <- sweep(X %*% W1, 2, b1, "+")   # weighted sums, hidden layer         (n x H)
  A1 <- tanh(Z1)                       # activation - this is what bends the boundary
  Z2 <- A1 %*% W2 + b2                 # weighted sum, output                (n x 1)
  P  <- sigmoid(Z2)                    # probability of "inner"
  list(A1 = A1, P = P)
}

loss_hist <- numeric(0); snapshots <- list()
for (epoch in 1:500) {
  fw <- forward(X, W1, b1, W2, b2); P <- fw$P; A1 <- fw$A1
  loss_hist[epoch] <- -mean(y * log(P + 1e-9) + (1 - y) * log(1 - P + 1e-9))   # cross-entropy (A5)

  # BACKPROPAGATION (A7), in matrix form
  dZ2 <- (P - y) / n                   # delta at the output
  dW2 <- t(A1) %*% dZ2;  db2 <- sum(dZ2)
  dA1 <- dZ2 %*% t(W2)                 # pass the blame back through W2
  dZ1 <- dA1 * (1 - A1^2)              # through tanh (derivative 1 - a^2)
  dW1 <- t(X) %*% dZ1;   db1 <- colSums(dZ1)

  # GRADIENT DESCENT (A6)
  W1 <- W1 - lr * dW1; b1 <- b1 - lr * db1
  W2 <- W2 - lr * dW2; b2 <- b2 - lr * db2

  if (epoch %in% c(1, 10, 50, 500)) snapshots[[as.character(epoch)]] <- list(W1 = W1, b1 = b1, W2 = W2, b2 = b2)
}

tibble(epoch = seq_along(loss_hist), loss = loss_hist) |>
  ggplot(aes(epoch, loss)) + geom_line(linewidth = 1) + theme_minimal() +
  labs(title = "Training loss: gradient descent walking downhill")


# ---- B3 · Watch the boundary bend ------------------------------------------

## ---- boundary ----
grid_xy <- expand_grid(x1 = seq(-3, 3, by = 0.05), x2 = seq(-3, 3, by = 0.05))
boundary_at <- function(ep) {
  s <- snapshots[[ep]]
  grid_xy |>
    mutate(p = as.vector(forward(as.matrix(grid_xy), s$W1, s$b1, s$W2, s$b2)$P)) |>
    ggplot(aes(x1, x2)) +
    geom_raster(aes(fill = p)) +
    geom_point(data = toy, aes(colour = class), size = 1, show.legend = FALSE) +
    scale_fill_viridis_c(limits = c(0, 1), name = "P(inner)") +
    scale_colour_manual(values = c("white", "black")) +
    coord_equal() + theme_minimal() + labs(title = paste("epoch", ep))
}
boundary_at("1") + boundary_at("10") + boundary_at("50") + boundary_at("500") + plot_layout(guides = "collect")

fw <- forward(X, W1, b1, W2, b2)
mean((fw$P > 0.5) == (y == 1))        # accuracy after 500 epochs


# ---- Part C · Neural networks in tidymodels --------------------------------


# ---- C1 · `mlp()` with the `nnet` engine -----------------------------------

## ---- nnet ----
nn_spec <- mlp(hidden_units = 8, penalty = 0.01, epochs = 200) |>
  set_engine("nnet", MaxNWts = 10000) |>      # raise nnet's default cap of 1,000 weights
  set_mode("classification")
# penalty = weight decay (A9); epochs = maximum optimiser iterations

nn_wf <- workflow(dm_rec, nn_spec)

set.seed(2026)
nn_res <- fit_resamples(nn_wf, dm_folds, metrics = cls_metrics, control = control_resamples(save_pred = TRUE))
collect_metrics(nn_res)


# ---- C2 · Under- and over-regularised --------------------------------------

## ---- nn-sweep ----
nn <- function(units, decay) mlp(hidden_units = units, penalty = decay, epochs = 200) |>
  set_engine("nnet", MaxNWts = 10000) |> set_mode("classification")

set.seed(2026)
nn_sweep <- workflow_set(
  preproc = list(base = dm_rec),
  models  = list(tiny_no_decay = nn(2, 0), big_no_decay = nn(30, 0), big_with_decay = nn(30, 0.05))
) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026)

collect_metrics(nn_sweep) |> filter(.metric %in% c("roc_auc", "brier_class")) |> select(wflow_id, .metric, mean, std_err)


# ---- C3 · Tune it like any other model -------------------------------------

## ---- nn-tune ----
nn_tune_wf <- workflow(dm_rec, mlp(hidden_units = tune(), penalty = tune(), epochs = 200) |>
                         set_engine("nnet", MaxNWts = 10000) |> set_mode("classification"))

nn_params <- extract_parameter_set_dials(nn_tune_wf) |>
  update(hidden_units = hidden_units(range = c(2L, 24L)),
         penalty      = penalty(range = c(-4, -0.5)))      # log10: 0.0001 .. 0.32

set.seed(2026)
nn_race <- tune_race_anova(nn_tune_wf, resamples = dm_folds, param_info = nn_params, grid = 16,
                           metrics = metric_set(roc_auc, brier_class), control = control_race(verbose_elim = TRUE))
show_best(nn_race, metric = "roc_auc", n = 5)
autoplot(nn_race, metric = "roc_auc") + theme_minimal()

nn_final_wf <- finalize_workflow(nn_tune_wf, select_best(nn_race, metric = "roc_auc"))
nn_last     <- last_fit(nn_final_wf, dm_split, metrics = cls_metrics)
collect_metrics(nn_last)
nn_fit <- extract_workflow(nn_last)
saveRDS(nn_last, "outputs/t07_nn_last.rds")


# ---- C4 · Deeper, with torch: the `brulee` engine *(only if torch is installed — see Setup)* 

## ---- brulee ----
torch_ok <- requireNamespace("brulee", quietly = TRUE) && requireNamespace("torch", quietly = TRUE) &&
  tryCatch(torch::torch_is_installed(), error = function(e) FALSE)
torch_ok

## ---- brulee-fit ----
if (torch_ok) {
  # two hidden layers (32 -> 16), ReLU, dropout, mini-batch SGD with momentum, early stopping on a 10% validation slice
  deep_spec <- mlp(hidden_units = c(32L, 16L), epochs = 150, learn_rate = 0.005, dropout = 0.2, penalty = 0,
                   activation = "relu") |>
    set_engine("brulee", optimizer = "SGD", batch_size = 256, momentum = 0.9, stop_iter = 15, validation = 0.1) |>
    set_mode("classification")

  set.seed(2026)
  deep_fit <- workflow(dm_rec, deep_spec) |> fit(dm_train)
  print(deep_fit |> extract_fit_engine() |> autoplot() + theme_minimal() +
          labs(title = "brulee: validation loss by epoch (early stopping)"))
  print(augment(deep_fit, dm_test) |> cls_metrics(truth = undx_dm, estimate = .pred_class, .pred_Yes))
} else {
  message("torch is not installed on this machine - skipping the brulee network (see Setup). Nothing below depends on it.")
}


# ---- C5 · Explain the network with this morning's code ---------------------

## ---- nn-shap ----
pred_yes <- function(model, newdata, ...) predict(model, newdata, type = "prob")$.pred_Yes
set.seed(2026)
X_explain <- dm_train |> select(-undx_dm) |> slice_sample(n = 200)     # cost ~ rows x background x features: keep these small
X_bg      <- dm_train |> select(-undx_dm) |> slice_sample(n = 80)

sv_nn <- kernelshap(nn_fit, X = X_explain, bg_X = X_bg, pred_fun = pred_yes, verbose = FALSE) |> shapviz()   # 1-3 min
sv_importance(sv_nn, kind = "beeswarm", max_display = 15) + labs(title = "SHAP: tuned neural network")
sv_dependence(sv_nn, v = "bmi", color_var = "fam_hx_dm") + labs(title = "Network: BMI x family history")


# ---- C6 · The verdict: four families, one test set -------------------------

## ---- verdict ----
lr_last  <- last_fit(workflow(dm_rec, logistic_reg() |> set_engine("glm")), dm_split, metrics = cls_metrics)
rf_last  <- last_fit(workflow(dm_rec, rand_forest(trees = 500, mtry = 6, min_n = 10) |> set_engine("ranger") |> set_mode("classification")), dm_split, metrics = cls_metrics)
svm_last <- last_fit(workflow(dm_rec, svm_rbf(cost = 1, rbf_sigma = 0.005) |> set_engine("kernlab") |> set_mode("classification")), dm_split, metrics = cls_metrics)
xgb_last <- if (file.exists("outputs/t05_xgb_last.rds")) readRDS("outputs/t05_xgb_last.rds") else NULL

verdict <- bind_rows(
  logistic_baseline = collect_metrics(lr_last),
  random_forest     = collect_metrics(rf_last),
  svm_rbf           = collect_metrics(svm_last),
  xgboost_tuned     = if (!is.null(xgb_last)) collect_metrics(xgb_last) else NULL,
  neural_net_tuned  = collect_metrics(nn_last),
  .id = "model"
) |>
  select(model, .metric, .estimate) |>
  pivot_wider(names_from = .metric, values_from = .estimate) |>
  arrange(desc(roc_auc))
verdict
saveRDS(verdict, "outputs/t07_verdict.rds")


# ---- Your turn (25 min) ----------------------------------------------------


# ---- Task A · Count the parameters, then watch them overfit ----------------


# ---- Solution A ------------------------------------------------------------

## ---- solA ----
n_in <- dm_rec |> prep() |> bake(new_data = NULL) |> select(-undx_dm) |> ncol()
c(inputs = n_in, weights = n_in * 40 + 40 + 40 + 1, people_per_fold = round(nrow(dm_train) * 4 / 5))

set.seed(2026)
nn_three <- workflow_set(preproc = list(base = dm_rec),
                         models = list(small = nn(4, 0.01), big_free = nn(40, 0), big_decay = nn(40, 0.05))) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026)
collect_metrics(nn_three) |> filter(.metric %in% c("roc_auc", "brier_class")) |> select(wflow_id, .metric, mean, std_err)


# ---- Task B · Does it see the same world? ----------------------------------


# ---- Solution B ------------------------------------------------------------


# ---- Task C · Stretch (needs torch) ----------------------------------------


# ---- Solution C (discussion) -----------------------------------------------


# ---- Take-home challenge: who has undiagnosed hypertension? ----------------


# ---- What to remember ------------------------------------------------------

