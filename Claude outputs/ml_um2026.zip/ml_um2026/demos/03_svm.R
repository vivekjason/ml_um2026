# =============================================================================
# Tutorial 3 · Support vector machines
# Extracted from tutorials/03_svm.qmd - the tutorial is the source of truth (instructor/purl_demos.R regenerates this).
# Run chunk by chunk with Ctrl+Enter. '## ----' lines are the tutorial's chunk labels.
# =============================================================================


# ---- What you will do ------------------------------------------------------


# ---- 0 · Start -------------------------------------------------------------

## ---- setup ----
source("R/prep_nhms.R")
library(patchwork)
library(future)
plan(multisession, workers = max(1, parallel::detectCores() - 1))


# ---- 1 · The idea, in four pictures ----------------------------------------


# ---- In one paragraph ------------------------------------------------------


# ---- 2 · What an SVM needs from the recipe ---------------------------------

## ---- rec ----
dm_rec


# ---- 3 · Three kernels, one workflow ---------------------------------------

## ---- specs ----
svm_lin_spec  <- svm_linear(cost = 1) |> set_engine("kernlab") |> set_mode("classification")
svm_poly_spec <- svm_poly(cost = 1, degree = 2) |> set_engine("kernlab") |> set_mode("classification")
svm_rbf_spec  <- svm_rbf(cost = 1, rbf_sigma = 0.005) |> set_engine("kernlab") |> set_mode("classification")

## ---- fit-rbf ----
svm_rbf_fit <- workflow(dm_rec, svm_rbf_spec) |> fit(dm_train)
svm_rbf_fit |> extract_fit_engine()

## ---- predict-rbf ----
augment(svm_rbf_fit, dm_train) |> cls_metrics(truth = undx_dm, estimate = .pred_class, .pred_Yes)


# ---- 4 · Honest comparison on the five folds -------------------------------

## ---- cv ----
set.seed(2026)
svm_res <- workflow_set(
  preproc = list(base = dm_rec),
  models  = list(linear = svm_lin_spec, poly2 = svm_poly_spec, rbf = svm_rbf_spec)
) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = cls_metrics, seed = 2026, verbose = TRUE)

rank_results(svm_res, rank_metric = "roc_auc", select_best = TRUE) |>
  filter(.metric %in% c("roc_auc", "brier_class")) |>
  select(wflow_id, .metric, mean, std_err)
autoplot(svm_res, metric = c("roc_auc", "brier_class"))


# ---- 5 · Where SVMs fit today ----------------------------------------------

## ---- save ----
dir.create("outputs", showWarnings = FALSE)
saveRDS(svm_res, "outputs/t03_svm_res.rds")    # kept for reference; nothing later depends on it


# ---- Your turn (15 min) ----------------------------------------------------


# ---- Task A · Cost and overfitting -----------------------------------------


# ---- Solution A ------------------------------------------------------------

## ---- solA ----
costs <- c(0.1, 1, 10, 100)
svm_costs <- lapply(costs, \(cst) svm_rbf(cost = cst, rbf_sigma = 0.005) |> set_engine("kernlab") |> set_mode("classification"))
names(svm_costs) <- paste0("cost_", costs)

set.seed(2026)
cost_cv <- workflow_set(preproc = list(base = dm_rec), models = svm_costs) |>
  workflow_map("fit_resamples", resamples = dm_folds, metrics = metric_set(roc_auc), seed = 2026)

cv_auc <- collect_metrics(cost_cv) |>
  transmute(cost = readr::parse_number(wflow_id), cv_auc = mean, se = std_err)

train_auc <- tibble(
  cost = costs,
  train_auc = sapply(svm_costs, \(spec) workflow(dm_rec, spec) |> fit(dm_train) |>
                       augment(dm_train) |> roc_auc(undx_dm, .pred_Yes) |> pull(.estimate))
)

left_join(cv_auc, train_auc, by = "cost")


# ---- Task B · What happens without scaling? (5 min) ------------------------


# ---- Solution B ------------------------------------------------------------

## ---- solB ----
rec_noscale <- recipe(undx_dm ~ ., data = dm_train) |>
  step_impute_median(all_numeric_predictors()) |>
  step_impute_mode(all_nominal_predictors()) |>
  step_dummy(all_nominal_predictors()) |>
  step_zv(all_predictors())

svm_raw_spec <- svm_rbf(cost = 1, rbf_sigma = 0.005) |>
  set_engine("kernlab", scaled = FALSE) |>      # stop kernlab from standardising internally
  set_mode("classification")

set.seed(2026)
noscale_res <- fit_resamples(workflow(rec_noscale, svm_raw_spec), dm_folds, metrics = metric_set(roc_auc, brier_class))
collect_metrics(noscale_res)


# ---- What to remember ------------------------------------------------------

