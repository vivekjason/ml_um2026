# =============================================================================
# Tutorial 1 · The pipeline: split, recipe, workflow, baseline
# Extracted from tutorials/01_pipeline.qmd - the tutorial is the source of truth (instructor/purl_demos.R regenerates this).
# Run chunk by chunk with Ctrl+Enter. '## ----' lines are the tutorial's chunk labels.
# =============================================================================


# ---- What you will do ------------------------------------------------------


# ---- 1 · Packages ----------------------------------------------------------

## ---- setup ----
library(tidymodels)    # rsample, recipes, parsnip, workflows, tune, yardstick, dials, broom, dplyr, ggplot2 ...
library(skimr)         # one-line data summaries
library(naniar)        # missingness plots
tidymodels_prefer()    # when two packages export the same name, prefer the tidymodels one


# ---- 2 · Look before you model ---------------------------------------------

## ---- read ----
nhms_raw <- readr::read_csv("data/nhms_synthetic.csv", show_col_types = FALSE)
glimpse(nhms_raw)

## ---- skim ----
skim(nhms_raw)

## ---- prevalence ----
nhms_raw |> count(undx_dm) |> mutate(prop = n / sum(n))


# ---- Missingness -----------------------------------------------------------

## ---- missing ----
gg_miss_var(nhms_raw, show_pct = TRUE)

nhms_raw |>
  mutate(bmi_missing = is.na(bmi)) |>
  group_by(bmi_missing) |>
  summarise(n = n(), mean_age = mean(age), pct_rural = mean(residential == 1))


# ---- The sentinel problem --------------------------------------------------

## ---- sentinel ----
summary(nhms_raw$sys)
ggplot(nhms_raw, aes(sys)) + geom_histogram(binwidth = 2) +
  labs(title = "Systolic BP, raw", subtitle = "Nobody has a systolic pressure of -9")


# ---- 3 · Clean: sentinels → `NA`, codes → labelled factors -----------------

## ---- clean ----
nhms <- nhms_raw |>
  mutate(across(c(sys, dys, rbs, rchol), \(x) na_if(x, -9))) |>
  mutate(
    # OUTCOMES: the event level ("Yes") comes FIRST. yardstick treats the first level as the event of interest.
    undx_dm     = factor(undx_dm,   levels = c(1, 0), labels = c("Yes", "No")),
    undx_hpt    = factor(undx_hpt,  levels = c(1, 0), labels = c("Yes", "No")),
    undx_chol   = factor(undx_chol, levels = c(1, 0), labels = c("Yes", "No")),
    sex         = factor(sex,         levels = 1:2, labels = c("Female", "Male")),
    age_cat     = factor(age_cat,     levels = 1:5, labels = c("18-29", "30-39", "40-49", "50-59", "60+")),
    ethnic      = factor(ethnic,      levels = 1:5, labels = c("Malay", "Chinese", "Indian", "Other Bumiputera", "Others")),
    residential = factor(residential, levels = 1:2, labels = c("Rural", "Urban")),
    married     = factor(married,     levels = 1:3, labels = c("Single", "Married", "Widowed/Divorced")),
    education   = factor(education,   levels = 1:4, labels = c("None", "Primary", "Secondary", "Tertiary")),
    income      = factor(income,      levels = c(3, 1, 2), labels = c("B40", "M40", "T20")),   # odd coding in the source file
    occupation  = factor(occupation,  levels = 1:5, labels = c("Government", "Private", "Self-employed", "Homemaker", "Not working")),
    cons_fv     = factor(cons_fv,     levels = 1:2, labels = c("Adequate", "Inadequate")),
    alcohol     = factor(alcohol,     levels = 1:2, labels = c("Yes", "No")),
    smoke       = factor(smoke,       levels = 1:3, labels = c("Current", "Former", "Never")),
    pa          = factor(pa,          levels = 1:2, labels = c("Active", "Inactive")),
    pa_3cat     = factor(pa_3cat,     levels = 1:3, labels = c("Low", "Moderate", "High")),
    fam_hx_dm   = factor(fam_hx_dm,   levels = 1:2, labels = c("Yes", "No")),
    fam_hx_hpt  = factor(fam_hx_hpt,  levels = 1:2, labels = c("Yes", "No")),
    bmi_cat     = factor(bmi_cat,     levels = 1:3, labels = c("<25", "25-29.9", "30+"))
  )

levels(nhms$undx_dm)     # must be "Yes" "No" - check this every single time
summary(nhms$sys)        # NAs instead of -9s


# ---- The event-level rule --------------------------------------------------


# ---- 4 · The naive model — a deliberate mistake ----------------------------

## ---- naive ----
naive_data <- nhms |> select(-id, -undx_hpt, -undx_chol, -pa)   # `pa` is an exact recode of pa_3cat; keep one copy

set.seed(2026)
naive_split <- initial_split(naive_data, prop = 0.80, strata = undx_dm)
naive_train <- training(naive_split)
naive_test  <- testing(naive_split)

naive_rec <- recipe(undx_dm ~ ., data = naive_train) |>
  step_impute_median(all_numeric_predictors()) |>
  step_impute_mode(all_nominal_predictors()) |>
  step_dummy(all_nominal_predictors()) |>
  step_zv(all_predictors()) |>
  step_normalize(all_numeric_predictors())

lr_spec <- logistic_reg() |> set_engine("glm") |> set_mode("classification")

naive_fit <- workflow(naive_rec, lr_spec) |> fit(data = naive_train)

naive_preds <- augment(naive_fit, new_data = naive_test)   # test data + .pred_class + .pred_Yes + .pred_No
roc_auc(naive_preds, truth = undx_dm, .pred_Yes)

## ---- naive-coefs ----
tidy(naive_fit) |> arrange(desc(abs(statistic))) |> head(8)


# ---- Target leakage --------------------------------------------------------


# ---- 5 · The honest predictor set ------------------------------------------

## ---- honest ----
leaky_vars     <- c("rbs", "sys", "dys", "rchol")
redundant_vars <- c("pa")                       # exact recode of pa_3cat -> would make the GLM rank-deficient

dm_data <- nhms |>
  select(-id, -undx_hpt, -undx_chol, -all_of(leaky_vars), -all_of(redundant_vars))
ncol(dm_data)


# ---- 6 · Split — and lock the test set -------------------------------------

## ---- split ----
set.seed(2026)
dm_split <- initial_split(dm_data, prop = 0.80, strata = undx_dm)
dm_train <- training(dm_split)
dm_test  <- testing(dm_split)
dm_split

dm_train |> count(undx_dm) |> mutate(prop = n / sum(n))
dm_test  |> count(undx_dm) |> mutate(prop = n / sum(n))

## ---- folds ----
set.seed(2026)
dm_folds <- vfold_cv(dm_train, v = 5, strata = undx_dm)
dm_folds


# ---- 7 · The recipe: a plan, estimated later -------------------------------

## ---- recipe ----
dm_rec <- recipe(undx_dm ~ ., data = dm_train) |>
  step_impute_median(all_numeric_predictors()) |>   # numeric NAs -> median of the TRAINING data
  step_impute_mode(all_nominal_predictors()) |>     # factor NAs  -> most common level
  step_dummy(all_nominal_predictors()) |>           # factors -> 0/1 indicator columns
  step_zv(all_predictors()) |>                      # drop constant columns (dm, hpt, chol are all 0)
  step_normalize(all_numeric_predictors())          # centre + scale: needed by SVM and NN; harmless for trees

dm_rec

## ---- prep-bake ----
dm_prep     <- prep(dm_rec)
baked_train <- bake(dm_prep, new_data = NULL)      # NULL = the data it was prepped on
baked_test  <- bake(dm_prep, new_data = dm_test)   # the TEST set, transformed with TRAINING medians and SDs

dim(dm_train); dim(baked_train)                    # 33 columns in, ~46 out (dummies), 3 zero-variance gone
tidy(dm_prep, number = 1) |> head()                # the medians that were learned
tidy(dm_prep, number = 5) |> filter(terms == "age")# the mean and SD that were learned


# ---- Step order matters ----------------------------------------------------


# ---- 8 · Workflow = recipe + model -----------------------------------------

## ---- workflow ----
lr_wf  <- workflow(dm_rec, lr_spec)
lr_wf

lr_fit <- fit(lr_wf, data = dm_train)              # preps the recipe on dm_train, bakes it, fits the glm

## ---- odds-ratios ----
tidy(lr_fit, exponentiate = TRUE) |>               # odds ratios per 1 SD (we normalised)
  filter(term != "(Intercept)") |>
  arrange(p.value) |>
  head(12)


# ---- Predict on data the model has never seen ------------------------------

## ---- predict ----
lr_preds <- augment(lr_fit, new_data = dm_test)
lr_preds |> select(undx_dm, .pred_class, .pred_Yes, .pred_No) |> head()

cls_metrics <- metric_set(roc_auc, pr_auc, brier_class, accuracy, sensitivity, specificity)
cls_metrics(lr_preds, truth = undx_dm, estimate = .pred_class, .pred_Yes)

## ---- confmat ----
lr_preds |> conf_mat(truth = undx_dm, estimate = .pred_class)
lr_preds |> conf_mat(truth = undx_dm, estimate = .pred_class) |> autoplot(type = "heatmap")
lr_preds |> roc_curve(truth = undx_dm, .pred_Yes) |> autoplot()


# ---- 9 · Swap the engine in one line ---------------------------------------

## ---- glmnet ----
lasso_spec <- logistic_reg(penalty = 0.01, mixture = 1) |> set_engine("glmnet")
lasso_fit  <- lr_wf |> update_model(lasso_spec) |> fit(dm_train)
augment(lasso_fit, dm_test) |> roc_auc(truth = undx_dm, .pred_Yes)


# ---- From here on: `source("R/prep_nhms.R")` -------------------------------


# ---- Your turn (45 min, in pairs) ------------------------------------------


# ---- Task A · The leakage audit (10 min, no code) --------------------------


# ---- Solution A ------------------------------------------------------------


# ---- Task B · Two recipes, one model (25 min) ------------------------------

## ---- taskB-setup (YOUR TURN: fill the blanks; not run as-is) ----
# rec_b <- recipe(undx_dm ~ ., data = dm_train) |>
#   step_indicate_na(bmi, waist, occupation) |>          # B1. why must this come BEFORE imputation?
#   step_zv(all_predictors()) |>                           # constant columns would confuse the distance below
#   step_impute_knn(all_predictors(), neighbors = ___) |>  # B2. try 5
#   step_dummy(all_nominal_predictors()) |>
#   step_zv(all_predictors()) |>
#   step_normalize(all_numeric_predictors())
# 
# rec_b |> prep() |> bake(new_data = NULL) |> glimpse()   # B3. which new columns appeared?
# 
# set.seed(2026)
# res_a <- fit_resamples(workflow(dm_rec, lr_spec), resamples = ___, metrics = metric_set(roc_auc, brier_class))
# set.seed(2026)
# res_b <- fit_resamples(workflow(___, ___),   resamples = ___, metrics = metric_set(roc_auc, brier_class))
# 
# bind_rows(median_mode = collect_metrics(res_a), knn_indicator = collect_metrics(res_b), .id = "recipe") |>
#   select(recipe, .metric, mean, std_err)


# ---- Solution B ------------------------------------------------------------

## ---- solB ----
rec_b <- recipe(undx_dm ~ ., data = dm_train) |>
  step_indicate_na(bmi, waist, occupation) |>
  step_zv(all_predictors()) |>
  step_impute_knn(all_predictors(), neighbors = 5) |>
  step_dummy(all_nominal_predictors()) |>
  step_zv(all_predictors()) |>
  step_normalize(all_numeric_predictors())

rec_b |> prep() |> bake(new_data = NULL) |> select(starts_with("na_ind")) |> head(3)

set.seed(2026)
res_a <- fit_resamples(workflow(dm_rec, lr_spec), resamples = dm_folds, metrics = metric_set(roc_auc, brier_class))
set.seed(2026)
res_b <- fit_resamples(workflow(rec_b, lr_spec),  resamples = dm_folds, metrics = metric_set(roc_auc, brier_class))

bind_rows(median_mode = collect_metrics(res_a), knn_indicator = collect_metrics(res_b), .id = "recipe") |>
  select(recipe, .metric, mean, std_err)


# ---- Task C · Stretch (if you finish early) --------------------------------


# ---- Solution C ------------------------------------------------------------

## ---- solC ----
rec_c <- recipe(undx_dm ~ ., data = dm_train) |>
  step_impute_median(all_numeric_predictors()) |>
  step_impute_mode(all_nominal_predictors()) |>
  step_other(occupation, threshold = 0.05) |>
  step_dummy(all_nominal_predictors()) |>
  step_interact(~ starts_with("sex_"):waist) |>
  step_zv(all_predictors()) |>
  step_normalize(all_numeric_predictors())

set.seed(2026)
res_c <- fit_resamples(workflow(rec_c, lr_spec), resamples = dm_folds, metrics = metric_set(roc_auc, brier_class))
collect_metrics(res_c)

lasso_fit <- workflow(dm_rec, logistic_reg(penalty = 0.01, mixture = 1) |> set_engine("glmnet")) |> fit(dm_train)
tidy(lasso_fit) |> filter(estimate == 0) |> nrow()


# ---- Debrief (12.45) -------------------------------------------------------


# ---- Debrief answers -------------------------------------------------------


# ---- What to remember ------------------------------------------------------

