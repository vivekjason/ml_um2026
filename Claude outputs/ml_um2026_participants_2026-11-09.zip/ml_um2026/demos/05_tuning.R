# =============================================================================
# Tutorial 5 · Resampling and tuning
# Extracted from tutorials/05_tuning.qmd - the tutorial is the source of truth (instructor/purl_demos.R regenerates this).
# Run chunk by chunk with Ctrl+Enter. '## ----' lines are the tutorial's chunk labels.
# =============================================================================


# ---- What you will do ------------------------------------------------------


# ---- 0 · Start -------------------------------------------------------------

## ---- setup ----
# WHERE WE ARE ---------------------------------------------------------------------------------------------
# Three families and a baseline, compared on the same folds (T4 bake-off). Every one of them used hand-picked
# hyperparameters. NEW TODAY: tune() replaces the hand-picked values - grids, racing, the one-SE rule - and the
# tuned XGBoost is saved to outputs/t05_xgb_last.rds, which Tutorials 6 and 7 load instead of refitting.
source("R/prep_nhms.R")
library(finetune)
library(future)
plan(multisession, workers = max(1, parallel::detectCores() - 1))
dir.create("outputs", showWarnings = FALSE)

lr_wf <- workflow(dm_rec, logistic_reg() |> set_engine("glm"))


# ---- 1 · Why one split lies ------------------------------------------------

## ---- many-splits ----
set.seed(1)
many_splits <- mc_cv(dm_data, prop = 0.80, times = 25, strata = undx_dm)   # Monte-Carlo CV = repeated random splits

set.seed(1)
lr_many <- fit_resamples(lr_wf, many_splits, metrics = metric_set(roc_auc))

collect_metrics(lr_many, summarize = FALSE) |>
  ggplot(aes(.estimate)) +
  geom_histogram(bins = 12, fill = "#0b4f6c") +
  labs(x = "test-set AUC", y = NULL, title = "Same model, 25 random splits",
       subtitle = "Whoever reported the maximum would be lying by accident") +
  theme_minimal()

collect_metrics(lr_many)     # mean and std_err: THIS is what to report


# ---- 2 · The resampling menu -----------------------------------------------

## ---- menu ----
dm_folds                                                     # 5-fold, stratified: what we have used all along
vfold_cv(dm_train, v = 10, repeats = 3, strata = undx_dm)    # 30 fits: less variance, 6x the cost
bootstraps(dm_train, times = 25, strata = undx_dm)           # sample WITH replacement; out-of-bag rows = assessment

## ---- inside-fold ----
dm_folds$splits[[1]]
analysis(dm_folds$splits[[1]])   |> nrow()    # the 4/5 used for fitting: recipe prepped HERE, model fitted HERE
assessment(dm_folds$splits[[1]]) |> nrow()    # the 1/5 held out: baked with the analysis set's medians and SDs


# ---- 3 · Tuning: mark, bound, search ---------------------------------------


# ---- Mark what to tune -----------------------------------------------------

## ---- tune-spec ----
xgb_tune_spec <- boost_tree(trees = 500, learn_rate = tune(), tree_depth = tune(), min_n = tune(), sample_size = tune()) |>
  set_engine("xgboost") |>
  set_mode("classification")

xgb_tune_wf <- workflow(dm_rec, xgb_tune_spec)


# ---- Bound the search space (`dials`) --------------------------------------

## ---- params ----
xgb_params <- extract_parameter_set_dials(xgb_tune_wf) |>
  update(
    learn_rate  = learn_rate(range = c(-2.5, -0.5)),    # log10 scale -> 0.003 .. 0.32
    tree_depth  = tree_depth(range = c(2L, 8L)),
    min_n       = min_n(range = c(5L, 60L)),
    sample_size = sample_prop(range = c(0.5, 1))
  )
xgb_params


# ---- Lay out the candidates ------------------------------------------------

## ---- grids ----
grid_regular(xgb_params, levels = 3) |> nrow()          # 3^4 = 81 candidates, only 3 distinct values each
set.seed(2026)
xgb_grid <- grid_space_filling(xgb_params, size = 20)   # 20 candidates spread evenly over the 4-D space
xgb_grid


# ---- Search: every candidate × every fold ----------------------------------

## ---- tune-grid ----
set.seed(2026)
t0 <- Sys.time()
xgb_tuned <- tune_grid(xgb_tune_wf, resamples = dm_folds, grid = xgb_grid,
                       metrics = metric_set(roc_auc, brier_class), control = control_grid(save_pred = TRUE))
Sys.time() - t0

collect_metrics(xgb_tuned) |> filter(.metric == "roc_auc") |> arrange(desc(mean)) |> head()
autoplot(xgb_tuned, metric = "roc_auc") + theme_minimal()


# ---- Choose ----------------------------------------------------------------

## ---- select ----
show_best(xgb_tuned, metric = "roc_auc", n = 5)

select_best(xgb_tuned, metric = "roc_auc")                                      # numerically best
select_by_one_std_err(xgb_tuned, metric = "roc_auc", tree_depth, desc(min_n))   # SIMPLEST within 1 SE of best


# ---- The one-standard-error rule -------------------------------------------


# ---- 4 · Racing: stop wasting folds on hopeless candidates -----------------

## ---- race ----
set.seed(2026)
t0 <- Sys.time()
xgb_race <- tune_race_anova(xgb_tune_wf, resamples = dm_folds, param_info = xgb_params, grid = 30,
                            metrics = metric_set(roc_auc, brier_class),
                            control = control_race(verbose_elim = TRUE, save_pred = TRUE))
Sys.time() - t0
plot_race(xgb_race) + theme_minimal()
show_best(xgb_race, metric = "roc_auc", n = 5)


# ---- Also available: Bayesian optimisation ---------------------------------

## ---- bayes (YOUR TURN: fill the blanks; not run as-is) ----
# set.seed(2026)
# xgb_bayes <- tune_bayes(xgb_tune_wf, resamples = dm_folds, initial = xgb_tuned, iter = 10, param_info = xgb_params,   # seed it with the grid results
#                         metrics = metric_set(roc_auc, brier_class), control = control_bayes(no_improve = 5, verbose_iter = TRUE))
# autoplot(xgb_bayes, type = "performance")


# ---- 5 · Finalise — and the test set, once ---------------------------------

## ---- finalize ----
xgb_final_wf <- finalize_workflow(xgb_tune_wf, select_best(xgb_race, metric = "roc_auc"))
xgb_final_wf

xgb_last <- last_fit(xgb_final_wf, split = dm_split, metrics = cls_metrics)
collect_metrics(xgb_last)

## ---- compare-lr ----
set.seed(2026)
lr_last <- last_fit(lr_wf, split = dm_split, metrics = cls_metrics)
bind_rows(logistic = collect_metrics(lr_last), xgb_tuned = collect_metrics(xgb_last), .id = "model") |>
  select(model, .metric, .estimate) |>
  pivot_wider(names_from = model, values_from = .estimate)

xgb_fit <- extract_workflow(xgb_last)     # the fitted workflow: save it, deploy it, explain it tomorrow
saveRDS(xgb_last, "outputs/t05_xgb_last.rds")
saveRDS(xgb_race, "outputs/t05_xgb_race.rds")


# ---- 6 · Two things to know, not to do today -------------------------------


# ---- Your turn (10 min) ----------------------------------------------------


# ---- Task A · Tune the random forest (or the SVM) with racing --------------

## ---- taskA (YOUR TURN: fill the blanks; not run as-is) ----
# n_pred <- dm_rec |> prep() |> bake(new_data = NULL) |> select(-undx_dm) |> ncol()   # upper limit for mtry
# 
# rf_tune_wf <- workflow(dm_rec, rand_forest(trees = 500, mtry = tune(), min_n = tune()) |>
#                          set_engine("ranger") |> set_mode("classification"))
# rf_params <- extract_parameter_set_dials(rf_tune_wf) |>
#   update(mtry = mtry(range = c(2L, ___)), min_n = min_n(range = c(___, ___)))
# 
# set.seed(2026)
# rf_race <- tune_race_anova(rf_tune_wf, dm_folds, param_info = rf_params, grid = 15,
#                            metrics = metric_set(roc_auc, brier_class), control = control_race(verbose_elim = TRUE))
# plot_race(rf_race)
# show_best(rf_race, metric = "roc_auc", n = 5)


# ---- Solution A ------------------------------------------------------------

## ---- solA ----
n_pred <- dm_rec |> prep() |> bake(new_data = NULL) |> select(-undx_dm) |> ncol()

rf_tune_wf <- workflow(dm_rec, rand_forest(trees = 500, mtry = tune(), min_n = tune()) |>
                         set_engine("ranger") |> set_mode("classification"))
rf_params <- extract_parameter_set_dials(rf_tune_wf) |>
  update(mtry = mtry(range = c(2L, 18L)), min_n = min_n(range = c(5L, 60L)))

set.seed(2026)
rf_race <- tune_race_anova(rf_tune_wf, dm_folds, param_info = rf_params, grid = 15,
                           metrics = metric_set(roc_auc, brier_class), control = control_race(verbose_elim = TRUE))
plot_race(rf_race) + theme_minimal()

top <- show_best(rf_race, metric = "roc_auc", n = 10) |> mutate(within_1se = mean >= max(mean) - std_err[1])
top
top |> filter(within_1se) |> arrange(desc(min_n), mtry) |> slice(1)


# ---- What to remember ------------------------------------------------------

